#!/bin/bash
cd "$(dirname "$0")"

if [ $# -eq 0 ]
  then
    echo "No arguments supplied"
    exit 1

fi


spark2-submit \
--master yarn \
--deploy-mode cluster  \
--name $1 \
--jars $2 \
$1
