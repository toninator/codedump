#!/bin/env bash

cd "$(dirname "$0")"

bash ./spark_submit.sh ./lipper/ltsf.py ./jars/spark-xml_2.11-0.5.0.jar
