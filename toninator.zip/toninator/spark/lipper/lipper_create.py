#!/usr/bin/env python

from pyspark.sql import SparkSession
from pyspark.sql.functions import input_file_name , explode, regexp_extract
#spark.conf.set("spark.sql.sources.partitionOverwriteMode","DYNAMIC")
import datetime

#LGDF

#pick latest week or month
df = spark.read.format('xml').options(rowTag='AssetOverview').load('/lasrim/data/raw/thomsonreuters/lipperxml/2019/05/06/Processed/*LGDF*.xml.gz').withColumn("full_filename",input_file_name())

lgdf =  df.withColumn("file",regexp_extract(df.full_filename,'Processed/(\w+)_\d+',1 )).withColumn("f_date",regexp_extract(df.full_filename,'_(\d+)?_',1 ))
lgdf_ao = lgdf.select([c for c in lgdf.columns if c not in {'ShareClasses'}])
lgdf_ao.write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_tnzs_test")


#lgdf_ao = lgdf.select([c for c in lgdf.columns if c not in {'ShareClasses'}])
#lgdf_ao.repartition(10).write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgdf_ao")

lgdf_ao = lgdf.select([c for c in lgdf.columns if c in {'ShareClasses', '_Id', 'file', 'full_filename','f_date'}])

#lgdf_ao_sc = lgdf_ao.select(lgdf_ao._Id,explode(lgdf_ao.ShareClasses.ShareClass).alias("share_class"),lgdf_ao.full_filename, lgdf_ao.file, lgdf_ao.f_date)
lgdf_ao_sc = lgdf_ao.select(lgdf_ao._Id,lgdf_ao.ShareClasses,lgdf_ao.full_filename, lgdf_ao.file, lgdf_ao.f_date)
lgdf_ao_sc.repartition(10).write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgdf_ao_sc")


lgdf = read_xml(f)
lgdf_ao = lgdf.select([c for c in lgdf.columns if c in {'ShareClasses', '_Id', 'file', 'full_filename','f_date'}])
lgdf_ao_sc = lgdf_ao.select(lgdf_ao._Id,explode(lgdf_ao.ShareClasses.Class).alias("class"),lgdf_ao._DeltaStatus,lgdf_ao.full_filename, lgdf_ao.file, lgdf_ao.f_date)
lgdf_ao.repartition(4).write.insertInto("standard.lipper_lgdf_ao_sc", overwrite=True)


#LGFF
lgff = spark.read.format('xml').options(rowTag='Feed').load('/lasrim/data/raw/thomsonreuters/lipperxml/2019/05/*/Processed/*_LGFF_*.xml.gz').withColumn("full_filename",input_file_name())

lgff2 = lgff.withColumn("file",regexp_extract(lgff_ao.full_filename,'Processed/([a-zA-Z_]+)_',1 )).withColumn("f_date",regexp_extract(lgff_ao.full_filename,'_(\d+)?_',1 ))
#lgff_ao2.repartition("f_date").write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgff_ao")

lgff_final = lgff2.write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgff")






