#!/usr/bin/env python

from pyspark.sql import SparkSession
from pyspark.sql.functions import input_file_name , explode, regexp_extract
#spark.conf.set("spark.sql.sources.partitionOverwriteMode","DYNAMIC")
import datetime

spark = SparkSession.builder\
    .master("yarn")\
    .appName("lipper_create")\
    .config("spark.driver.maxResultSize", "1g")\
    .getOrCreate()

spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
#spark.conf.set("spark.sql.shuffle.partitions", 1000)
sc = spark.sparkContext
for e in sc.getConf().getAll():
    print e


#LGFF
lgff_ao = spark.read.format('xml').options(rowTag='AssetOverview').load('/lasrim/data/raw/thomsonreuters/lipperxml/2019/05/*/Processed/*_LGFF_*.xml.gz').withColumn("full_filename",input_file_name())

lgff_ao2 = lgff_ao.withColumn("file",regexp_extract(lgff_ao.full_filename,'Processed/([a-zA-Z_]+)_',1 )).withColumn("f_date",regexp_extract(lgff_ao.full_filename,'_(\d+)?_',1 ))
#lgff_ao2.repartition("f_date").write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgff_ao")

lgff_ao2.write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgff_ao")

lgff_fh = spark.read.format('xml').options(rowTag='FlowsHistory').load('/lasrim/data/raw/thomsonreuters/lipperxml/2019/05/*/Processed/*_LGFF_*.xml.gz').withColumn("full_filename",input_file_name())

lgff_fh2 = lgff_fh.withColumn("file",regexp_extract(lgff_fh.full_filename,'Processed/([a-zA-Z_]+)_',1 )).withColumn("f_date",regexp_extract(lgff_fh.full_filename,'_(\d+)?_',1 ))
#lgff_ao2.repartition("f_date").write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgff_ao")

lgff_fh2.write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgff_fh")





