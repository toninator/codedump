
df_shareclass = spark.sql("""
select asset_overview_id,shareclass_id
from (
    select asset_overview_id,id as shareclass_id,row_number() over (partition by id order by date__ desc) as seq
from im_sz_lipper_ns.tr_lip_shareclasses_shareclass where id >= 68350000
) final where seq = 1
""")

#df_shareclass_part = df_shareclass.repartition(10,"shareclass_id")
df_shareclass.registerTempTable("shareclass")

df_a = spark.sql("select * from im_sz_lipper_ns.tr_lip_feed_assetoverview where date__ in ('20190520','20190521')")
df_b = spark.sql("select * from im_sz_lipper_ns.tr_lip_performance where date__ in ('20190520','20190521')")
df_c = spark.sql("select * from im_sz_lipper_ns.tr_lip_performance_rollingperformance where date__ in ('20190520','20190521')")
df_d = spark.sql("select * from im_sz_lipper_ns.tr_lip_performance_rollingperformance_return where date__ in ('20190520','20190521')")

df_a.repartition(20).registerTempTable("a")
df_b.repartition(20).registerTempTable("b")
df_c.repartition(20).registerTempTable("c")
df_d.repartition(20).registerTempTable("d")

df_daily_hist = spark.sql("""
select /*+ BROADCAST (shareclass) */
asset_overview_id
,performance_deltastatus
,series,startdate
,enddate
,currency
,value
,run_date
,file_name_pattern,date__ as file_date
,shareclass_id
,substring(cast (startdate as string),1,10) as p_date
from (
    select nvl(s.asset_overview_id,'00000000') as asset_overview_id
     ,a.asset_overview_id as shareclass_id
     ,b.performance_deltastatus
     ,c.rollingperformanceseries as series
     ,d.rollingperformance_returnstartdate as startdate
     ,d.rollingperformance_returnenddate as enddate
     ,d.currency
     ,d.value
     ,d.rundate__ as run_date
     ,a.date__
     ,regexp_replace(substr(regexp_extract(a.filename__,'.*\/(.*)',1),0,length(regexp_extract(a.filename__,'.*\/([a-zA-Z_]+)',1))-1),'full','') as file_name_pattern
 from  a
 join  b on a.asset_overview_id = b.asset_overview_id and b.date__ = a.date__ --and b.date__ in ('20190520','20190521')
 join  c on b.performance_jkid = c.performance_jkid and b.date__ = c.date__ --and c.date__ in ('20190520','20190521')
 join  d on c.rollingperformance_jkid = d.performance_rollingperformance_jkid and c.date__ = d.date__ --and d.date__ in ('20190520','20190521')
 left join shareclass s on cast(a.asset_overview_id as int) = s.shareclass_id
 where a.date__ in ('20190520','20190521')
  and b.date__ in ('20190520','20190521')
  and c.date__ in ('20190520','20190521')
  and d.date__ in ('20190520','20190521')
) final
where cast(shareclass_id as int) >= 68350000
and file_name_pattern like '%LTSF%'
""")

df_daily_hist.repartition(4,"shareclass_id").write.mode("overwrite").partitionBy("p_date").parquet("/user/tnzs/lipper_daily_hist/")


