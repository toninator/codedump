from pyspark.sql import SparkSession
from pyspark.sql.functions import input_file_name , explode, regexp_extract
import datetime


spark = SparkSession.builder\
    .master("yarn")\
    .appName("lipper_incremental")\
    .config("spark.driver.maxResultSize", "1g")\
    .getOrCreate()

spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
#spark.conf.set("spark.sql.shuffle.partitions", 1000)
sc = spark.sparkContext
for e in sc.getConf().getAll():
    print e

#function to get schema from hive tables
def get_schema(table):
    try:
        sch = spark.sql("select * from {0} where f_date = '0'".format(table)).schema
        return sch
    except Exception as e:
        print e
        return False
  
#function to file check in hdfs
def path_exist(path):
    try:
        rdd = sc.textFile(path)
        rdd.take(1)
        return True
    except Exception as e:
        return False

#function to read xml into dataframe, using schema read from target table
def read_xml(f,sch,record):
    df = spark.read.format('xml').options(rowTag=record).load(f,schema = sch).withColumn("full_filename",input_file_name())  
    df2 =  df.withColumn("file",regexp_extract(df.full_filename,'Processed/(\w+)_\d+',1 )).withColumn("f_date",regexp_extract(df.full_filename,'_(\d+)?_',1 ))
    return df2

#insert into dynamic hive partitions
def load_assetoverview(f,sch,table):
    df = read_xml(f,sch,'AssetOverview')
    df2 = df.select([c for c in df.columns if c not in {'ShareClasses'}])
    df2.write.insertInto(table, overwrite=True)

def load_shareclass(f,sch):
    df = read_xml(f,sch,'ShareClass')
    df.write.insertInto("standard.lipper_lgdf_sc", overwrite=True)
    #df2 = df.select([c for c in df.columns if c in {'ShareClasses', '_Id', 'file', 'full_filename','f_date'}])
    #df3 = df2.select(df2._Id,df2.ShareClasses,df2.full_filename, df2.file, df2.f_date)
    #lgdf_ao_sc = lgdf_ao.select(lgdf_ao._Id,explode(lgdf_ao.ShareClasses.Class).alias("class"),lgdf_ao._DeltaStatus,lgdf_ao.full_filename, lgdf_ao.file, lgdf_ao.f_date)
    #df3.write.insertInto("standard.lipper_lgdf_sc", overwrite=True)

def load_flowhistory(f,sch):
    df = read_xml(f,sch,'FlowHistory')
    df.write.insertInto("standard.lipper_lgff_fh", overwrite=True)

#calculate the lookback yyyy and mm
def yymm(lookback):
    temp = datetime.datetime.now() + datetime.timedelta(lookback)
    return temp

yymm_past = '{0}{1}'.format(yymm(-10).year,yymm(-10).strftime('%m'))
yymm_today = '{0}{1}'.format(yymm(0).year,yymm(0).strftime('%m'))

if yymm_past == yymm_today:
    month_list = [yymm_today]
else:
    month_list = [yymm_past, yymm_today]

#sch_ao = spark.sql("select * from standard.lipper_lgdf_ao where f_date = '0'").schema
#sch_sc = spark.sql("select * from standard.lipper_lgdf_ao_sc where f_date = '0'").schema
#sch_ao = spark.sql("select * from standard.lipper_lgdf_ao where f_date = '0'").schema
#sch_ao = spark.sql("select * from standard.lipper_lgdf_ao where f_date = '0'").schema

#loop through files with yyyymmd filters in list
for m in month_list:
    for i in [m+"0",m+"1",m+"2",m+"3"]:
        print i
        try:
            lgdf = '/lasrim/data/raw/thomsonreuters/lipperxml/*/*/*/Processed/*LGDF_{0}*.xml.gz'.format(i)
            lgff = '/lasrim/data/raw/thomsonreuters/lipperxml/*/*/*/Processed/*LGFF_{0}*.xml.gz'.format(i)
            if path_exist(lgdf) == True:
                print '{0} exists!'.format(lgdf)
                load_assetoverview(lgdf,get_schema('standard.lipper_lgdf_ao'),'standard.lipper_lgdf_ao')
                load_shareclass(lgdf,get_schema('standard.lipper_lgdf_sc'))
                print '***** DONE - {0} '.format(lgdf)
            else:
                print '***** No files in {0}'.format(lgdf)
                pass
            if path_exist(lgff) == True:
                print '{0} exists!'.format(lgff)
                load_assetoverview(lgff,get_schema('standard.lipper_lgff_ao'),'standard.lipper_lgff_ao')
                load_flowhistory(lgff,get_schema('standard.lipper_lgff_fh'))
                print '***** DONE - {0} '.format(lgff)
            else:
                print '***** No files in {0}'.format(lgff)
                continue
        except Exception as e:
            print '===================================='
            print '=Something went wrong on {0}, continue to next'.format(i)
            print '={}'.format(e)
            print '===================================='
            continue


