#!/usr/bin/env python

from pyspark.sql import SparkSession
from pyspark.sql.functions import input_file_name , explode, regexp_extract
#spark.conf.set("spark.sql.sources.partitionOverwriteMode","DYNAMIC")
import datetime

spark = SparkSession.builder\
    .master("yarn")\
    .appName("lipper_incremental")\
    .config("spark.driver.maxResultSize", "1g")\
    .getOrCreate()

spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
#spark.conf.set("spark.sql.shuffle.partitions", 1000)
sc = spark.sparkContext
for e in sc.getConf().getAll():
    print e

#LGDF

#pick latest week or month
#df = spark.read.format('xml').options(rowTag='ShareClass').load('/lasrim/data/raw/thomsonreuters/lipperxml/2019/05/*/Processed/*LGDF*.xml.gz').withColumn("full_filename",input_file_name())

df = spark.read.format('xml').options(rowTag='AssetOverview').load('/lasrim/data/raw/thomsonreuters/lipperxml/2019/05/*/Processed/*LGDF*FUL.xml.gz').withColumn("full_filename",input_file_name())

lgdf =  df.withColumn("file",regexp_extract(df.full_filename,'Processed/(\w+)_\d+',1 )).withColumn("f_date",regexp_extract(df.full_filename,'_(\d+)?_',1 ))
#lgdf_ao = lgdf.select([c for c in lgdf.columns if c not in {'ShareClasses'}])
#lgdf_ao.write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_tnzs_test")


#lgdf_ao = lgdf.select([c for c in lgdf.columns if c not in {'ShareClasses'}])
#lgdf_ao.repartition(10).write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgdf_ao")

lgdf_ao = lgdf.select([c for c in lgdf.columns if c in {'ShareClass', '_Id', 'file', 'full_filename','f_date'}])

#lgdf_ao_sc = lgdf_ao.select(lgdf_ao._Id,explode(lgdf_ao.ShareClasses.ShareClass).alias("share_class"),lgdf_ao.full_filename, lgdf_ao.file, lgdf_ao.f_date)
#lgdf_ao_sc = lgdf_ao.select(lgdf_ao._Id,lgdf_ao.ShareClasses,lgdf_ao.full_filename, lgdf_ao.file, lgdf_ao.f_date)
lgdf.printSchema()
lgdf_ao.write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgdf_sc")

#lgdf_pro = lgdf.select([c for c in lgdf.columns if c in {'Profile','_Id','file','full_filename','f_date'}])
#lgdf_pro.printSchema()
#lgdf_pro.write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgdf_sc_pro")

#LGFF
#lgff = spark.read.format('xml').options(rowTag='Feed').load('/lasrim/data/raw/thomsonreuters/lipperxml/2019/05/*/Processed/*_LGFF_*.xml.gz').withColumn("full_filename",input_file_name())

#lgff2 = lgff.withColumn("file",regexp_extract(lgff_ao.full_filename,'Processed/([a-zA-Z_]+)_',1 )).withColumn("f_date",regexp_extract(lgff_ao.full_filename,'_(\d+)?_',1 ))
#lgff_ao2.repartition("f_date").write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgff_ao")

#lgff_final = lgff2.write.mode("overwrite").partitionBy("f_date").saveAsTable("standard.lipper_lgff")






