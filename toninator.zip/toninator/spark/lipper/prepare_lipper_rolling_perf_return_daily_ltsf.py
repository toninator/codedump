#!/usr/bin/env python
from pyspark.sql import SparkSession
from pyspark.sql.functions import row_number


spark = SparkSession.builder\
    .master("yarn")\
    .appName("lipper_rolling_perf_return_daily_ltsf")\
    .config("spark.driver.maxResultSize", "1g")\
    .getOrCreate()


def create_ext(df,db,table,part_col,loc):
    try:
        buf = []
        buf.append('CREATE EXTERNAL TABLE {}.{} ('.format(db,table))
        keyanddatatypes =  df.dtypes
        sizeof = len(df.dtypes)
        print ("===== Number of Columns: ",sizeof)
        count=1;
        for eachvalue in keyanddatatypes:
            print count,sizeof,eachvalue
            col = eachvalue[0]
            dtype = eachvalue[1]
            if col == part_col:
                part_dtype = dtype
                continue
            if count == 1:
                total = '{} {} '.format(col,dtype) #str(col)+str(' ')+str(dtype)
            else:
                total = ',{} {} '.format(col,dtype) #str(col) + str(' ') + str(dtype) + str(',')
            buf.append(total)
            count = count + 1
        buf.append(' ) ')
        if part_col <>'':
            buf.append('PARTITIONED BY ( ') 
            buf.append('{} '.format(part_col))
            buf.append('{}) '.format(part_dtype))
        buf.append('STORED as parquet ')
        buf.append("LOCATION ")
        buf.append("'")
        buf.append(loc)
        buf.append("'")
        tabledef = ''.join(buf)
        print "---------print definition ---------"
        print tabledef
        spark.sql(tabledef)
    except Exception as e:
        print '=================='
        print 'Failed to create external table'
        print e
        print '=================='
        sys.exit(1)


db = 'im_pz_competitor_ns'
table = 'lipper_rolling_performance_return_daily_ltsf'
location = '/lasrim/data/prepared/IM_PZ_COMPETITOR_NS/lipper_rolling_performance_return_daily_ltsf'
prep = spark.sql('''
select 
ltsf.`_id` as asset_overview_id
,ltsf.performance.rollingperformance.`_series` as series
,r.`_currency` as currency
,cast(r.`_startdate` as timestamp) as startdate
,cast(r.`_enddate` as timestamp) as enddate
,cast(r.`_value` as decimal(10,8)) as value
,ltsf.file as file_name
,ltsf.run_id
,ltsf.f_date
,row_number() over(partition by ltsf.`_id`,r.`_currency`,r.`_startdate` order by ltsf.f_date , ltsf.run_id desc) as rn
from im_sz_lipper_ns.lipper_ltsf ltsf
lateral view explode(ltsf.performance.rollingperformance.return) tbl as r
where r.`_currency` = 'USD'
and f_date >= (select max(l.f_date) from im_sz_lipper_ns.lipper_ltsf l where l.file like '%full%')
''')

prep2 = prep.filter("rn = 1").drop("rn")

if spark._jsparkSession.catalog().tableExists(db,table) == False:
    create_ext(prep2,db,table,'',location)
else:
    print '==== External Table exists ===='

try:
    #prep.filter("rn = 1").drop("rn").coalesce(10).write.mode("overwrite").parquet("/lasrim/data/prepared/IM_PZ_COMPETITOR_NS/lipper_rolling_performance_return_daily_ltsf")
    prep2.coalesce(10).write.insertInto('{}.{}'.format(db,table),overwrite=True)
except Exception as e:
    print '=================='
    print 'Failed to filter, drop column, and write'
    print e
    print '=================='
    sys.exit(1)


