#!/usr/bin/env python
from pyspark.sql import SparkSession
from pyspark.sql.functions import input_file_name , explode, regexp_extract
import datetime


spark = SparkSession.builder\
    .master("yarn")\
    .appName("ltsf")\
    .config("spark.driver.maxResultSize", "1g")\
    .getOrCreate()


spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
spark.conf.set("hive.exec.dynamic.partition.mode","nonstrict")
sc = spark.sparkContext


#calculate the lookback yyyy and mm
def yymm(lookback):
    temp = datetime.datetime.now() + datetime.timedelta(lookback)
    return temp


#function to get schema from hive tables
def get_schema(table):
    try:
        sch = spark.sql("select performance as Performance, `_id` as `_Id` from {0} where f_date = '0'".format(table)).schema
        print sch
        return sch
    except Exception as e:
        print '===================================='
        print '=Schema not found on {0}'.format(table)
        print '={}'.format(e)
        print '===================================='    
        sys.exit(1)


#function to file check in hdfs
def path_exist(path):
    try:
        rdd = sc.textFile(path)
        rdd.take(1)
        return True
    except Exception as e:
        return False


#function to read xml into dataframe, using schema read from target table
def read_xml(f,sch,record):
    try:
        df = spark.read.format('xml').options(rowTag=record).load(f,schema = sch).withColumn("full_filename",input_file_name())
        #df = spark.read.format('xml').options(rowTag=record).load(f).withColumn("full_filename",input_file_name())
        df2 =  df.withColumn("file",regexp_extract(df.full_filename,'Processed/(\w+)_\d+',1 )).withColumn("f_date",regexp_extract(df.full_filename,'_(\d+)?_',1 ))
        df2.show(5,False)
        return df2
    except Exception as e:
        print '===================================='
        print '=Failed to read {0}'.format(f)
        print '={}'.format(e)
        print '===================================='
        sys.exit(1)


#insert into dynamic hive partitions, could be main
def load(f,sch,table):
    try:
        df = read_xml(f,sch,'AssetOverview')
        df.write.insertInto(table, overwrite=True)
    except Exception as e:
        print '===================================='
        print '=Failed to insert {0}'.format(table)
        print '={}'.format(e)
        print '===================================='
        sys.exit(1)


#yearmonth for today and past 14 days
yymm_past = '{0}{1}'.format(yymm(-14).year,yymm(-14).strftime('%m'))
yymm_today = '{0}{1}'.format(yymm(0).year,yymm(0).strftime('%m'))
print yymm_past
print yymm_today


if yymm_past == yymm_today:
    month_list = [yymm_today]
else:
    month_list = [yymm_past, yymm_today]


#loop through files with yyyymmd filters in list
for m in month_list:
    for i in [m+"0",m+"1",m+"2",m+"3"]:
        print i
        ltsf = '/lasrim/data/raw/thomsonreuters/lipperxml/*/*/*/Processed/*_LTSF_{0}*.xml.gz'.format(i)
        print 'Checking {0}'.format(ltsf)
        if path_exist(ltsf) == True:
            print '{0} exists!'.format(ltsf)
            load(ltsf,get_schema('im_sz_lipper_ns.lipper_ltsf'),'im_sz_lipper_ns.lipper_ltsf')
            print '***** DONE - {0} '.format(ltsf)
        else:
            print '***** No files in {0}'.format(ltsf)
            continue

