#!/bin/env bash

cd "$(dirname "$0")"

bash ./spark_submit.sh ./lipper/prepare_lipper_rolling_perf_return_daily_ltsf.py ./jars/empty.jar

