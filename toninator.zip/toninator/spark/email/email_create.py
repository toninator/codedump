#!/usr/bin/env python
from pyspark.sql import SparkSession
import pyspark.sql.functions as f
import datetime, sys

spark = SparkSession.builder\
    .master("yarn")\
    .appName("email_create_tables")\
    .getOrCreate()


spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
spark.conf.set("spark.sql.session.timeZone", "UTC")


#spark.conf.set("spark.sql.shuffle.partitions", 1000)
sc = spark.sparkContext
for e in sc.getConf().getAll():
    print e


def read_df(db, table, part_date, filter_date):
    select_sql = '''
select * 
from {0}.{1}
where date__ >= {2} --filter partition
and eventdate > = {3} --filter eventdate
'''.format(db, table,yyyymmdd,yyyymmdd_str)
    print select_sql
    df = spark.sql(select_sql)
    df2 = df.select([c for c in df.columns if '__' not in c]).dropDuplicates()
    df2.printSchema()
    return df2


def create_ext_table(df,db,table,part_col,loc):
    buf = []
    buf.append('CREATE EXTERNAL TABLE {}.{} ('.format(db,table))
    keyanddatatypes =  df.dtypes
    sizeof = len(df.dtypes)
    print ("===== Number of Columns: ",sizeof)
    count=1;
    for eachvalue in keyanddatatypes:
        print count,sizeof,eachvalue
        col = eachvalue[0]
        dtype = eachvalue[1]
        if col == part_col:
            part_dtype = dtype
            continue
        if count == 1:
            total = '{} {} '.format(col,dtype) #str(col)+str(' ')+str(dtype)
        else:
            total = ',{} {} '.format(col,dtype) #str(col) + str(' ') + str(dtype) + str(',')
        buf.append(total)
        count = count + 1
    buf.append(' ) ')
    if part_col <>'':
        buf.append('PARTITIONED BY ( ') 
        buf.append('{} '.format(part_col))
        buf.append('{}) '.format(part_dtype))
    buf.append(' STORED as parquet ')
    buf.append(" LOCATION ")
    buf.append("'")
    buf.append(loc)
    buf.append("'")
    ##partition by pt
    tabledef = ''.join(buf)
    print "---------print definition ---------"
    print tabledef
    spark.sql(tabledef)


def load_df(df, db,table):
    df.write.insertInto("{}.{}".format(db,table), overwrite=True)

#get lookback
#def yyyymmdd(lookback):
lookback = -3
delta = datetime.datetime.now() + datetime.timedelta(lookback)
yyyymmdd = '{0}{1}{2}'.format(delta.year,delta.strftime('%m'),delta.strftime('%d'))
yyyymmdd_str = '{0}-{1}-{2}'.format(delta.year,delta.strftime('%m'),delta.strftime('%d'))
print yyyymmdd
print yyyymmdd_str


source_db = 'standard'
target_db = 'mss_pz_exacttarget_s'
path = 'adl://adlseastus2lasr.azuredatalakestore.net/lasr/data/prepared/mss_pz_exacttarget_s/{}'


#read
tables = ['Sent','Bounces','Clicks','NotSent','Opens','Complaints','Conversions','InferredOpens','SendImpression','Surveys','ClickImpression']


#tables = ['Sent']
for tab in tables:
    part_col = 'eventdate'
    t_df = read_df(source_db,tab,yyyymmdd,yyyymmdd_str)
    loc = path.format(tab)
    table_exists = spark._jsparkSession.catalog().tableExists(target_db,tab)
    if not table_exists:
        create_ext_table(t_df,target_db,tab,part_col,loc)
    load_df (t_df,target_db,tab)



--conf spark.driver.extraJavaOptions=-Duser.timezone=UTC --conf spark.executor.extraJavaOptions=-Duser.timezone=UTC --conf spark.sql.session.timeZone=UTC --conf spark.driver.memory=4G --conf spark.executor.memory=4G --name ft


#insert

#create



ET:
Sent - eventdate
Bounces - eventdate
Clicks - eventdate
NotSent - eventdate
Opens - eventdate


Lists - datecreated
Unsubs - timestamp
SendJobs - schedtime,senttimw 
AdditionalEmailAttributes - schedtime,senttime
Subscribers - dateheld,datecreated,dateunsubscribed
ListMembership - datejoined, dateunsubscribed





Other:

Complaints - eventdate
Conversions - eventdate
InferredOpens - eventdate
SendImpression - eventdate
Surveys - eventdate
ClickImpression - eventdate


Attributes (no date column)
MultipleDataExtensionSendLists - datecreated
StatusChange - datechanged
SFMC_SubscriptionExtract - optindate_capitalideas,optoutdate_capitalideas,optindate_ria,optoutdate_ria,optindate_models,optoutdate_models,submitdate,optindate_advisorguide,optoutdate_advisorguide,optindate_advisorcom,optoutdate_advisorcom,optindate_lumin,optoutdate_lumin




CITemporary - eventdate


SendJobImpression - eventdate

#CISendable_v1 
#CISendable_v2
#ET

CIUnsubscribe - timestamp (no data)

DST_ACE - delete_time







-make sure we have incremental for R2,R3,R4 files
-make sure we have historical for R2,R3,R4 files
-make sure stories for pdw target R2,R3,R4 tables
-recon R2,R3,R4
