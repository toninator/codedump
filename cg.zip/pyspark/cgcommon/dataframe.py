"""
dataframe.py
~~~~~~~~~~~~
Module that hosts abstract functions dealing with spark dataframes
"""

import getpass, sys
from datetime import datetime
import pyspark.sql.functions as f
from pyspark.sql.types import *
from pyspark.sql.window import Window

import cgcommon.cgspark as cg


def extract_compare_set(spark, db, table, part_col=None, part_filter=None):
    """Filters and extracts compare set from target table based on CDC type, part_col"""
    print("Extracting compare set")
    table_exists = cg.table_check(spark, db, table)
    if not table_exists:
        print(f"In extract_compare_set: {db}.{table} does not exist, returning None")
        return None
    else:
        if part_col:
            print("Partition column found")
            target_query = f"select * from {db}.{table} where {part_col} >= '{part_filter}'"
        else:
            print("No part_col, returning entire target table")
            target_query = f"select * from {db}.{table}"

        target_df = spark.sql(target_query).drop(part_col)
        return target_df


def insert_into(spark, dataframe, log, db, table, parent_path, **kwargs):
    """Function to insert dataframe into target table, pass in dataframe and params object
       Expected kwargs are
       :part_number=int
       :part_column=string
       :part_column_type=string "date" or "string"
    """
    print(f"Trying to insert with kwargs: {kwargs}")
    if not parent_path:
        print("No parent_path set in conf.JSON, quitting job...")
        sys.exit(1)

    if dataframe:
        dataframe_head = len(dataframe.head(1))
    else:
        dataframe_head = 0

    if dataframe_head > 0:
        # vars set to None if kwargs not set
        part_num = kwargs.get("part_number")
        part_col = kwargs.get("part_column")
        part_reference = kwargs.get("part_reference")
        part_col_type = kwargs.get("part_column_type")
        target_path = f"{parent_path}/{db}/{table}"

        # check if target table exists and create
        cg.create_external(spark, dataframe, log, db, table, target_path, part_col)
        # add partition column if given from kwargs
        dataframe_final = add_partition_column(dataframe, part_col, part_reference, part_col_type)

        # if partition_number exists repartition
        if part_num and part_num > 1:
            dataframe_final = dataframe_final.repartition(part_num)

        dataframe_final.write.insertInto(f"{db}.{table}", overwrite=True)
        print("Insert done!")
    else:
        # if dataframe is None or empty
        print("No DATAFRAME returned after CDC function, no inserts!")

    return None


def add_dw_columns(df, p):
    """Adds datawarehouse columns with surrogate key"""
    print("Adding DW columns")
    # set runtime and user vars
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    user_account = getpass.getuser()

    cdc_type = p.cdc_type
    increment = p.increment
    if not cdc_type:
        print("No CDC type given, default to cdc_type=delete_insert")
        # set default to fact_delete_insert if not set in JSON
        cdc_type = "delete_insert"

    # initialize column dict
    dw_columns = dict()
    # set common DW columns for SCD1, SCD2, fact
    # for each field, have list of [value, datatype, ordering]
    dw_columns['dwcreatedate'] = [current_datetime, 'timestamp', 2]
    dw_columns['dwcreatebyname'] = [user_account, 'string', 3]
    dw_columns['dwcreatebyprocessid'] = [0, 'bigint', 4]
    dw_columns['dwupdatedate'] = [current_datetime, 'timestamp', 5]
    dw_columns['dwupdatebyname'] = [user_account, 'string', 6]
    dw_columns['dwupdatebyprocessid'] = [0, 'bigint', 7]
    dw_columns['dwversion'] = [0, 'int', 8]
    dw_columns['dwsourcesystemcode'] = ['PRD', 'string', 9]

    # initialize dw_df
    # dw_df = df
    # set columns specific to scd2
    if cdc_type == "scd2":
        dw_columns['dweffectivefromdate'] = ['1900-01-01', 'timestamp', 0]
        dw_columns['dweffectivetodate'] = ['9999-12-31', 'timestamp', 1]
        dw_df = df.withColumn(p.dw_key, f.lit(0).cast('bigint')).select(p.dw_key, *df.columns)
    # set columns specific to scd1 with surrogate key
    elif cdc_type == "upsert" and increment:
        dw_df = df.withColumn(p.dw_key, f.lit(0).cast('bigint')).select(p.dw_key, *df.columns)
    else:
        dw_df = df

    # adds other dw columns at the end with right order
    for column, data_type in sorted(dw_columns.items(), key=lambda item: item[1][2]):
        dw_df = dw_df.withColumn(column, f.lit(data_type[0]).cast(data_type[1]))

    datawarehouse_df = dw_df.select([c.lower() for c in dw_df.columns])

    return datawarehouse_df


def add_partition_column(df, partition_column, partition_reference, column_type=None):
    """Fucntion to append p_col if one is set from json config"""
    print("Adding partition columns")
    # add partition column if p.part_col is set
    if partition_column and partition_reference:     # == '' or column_name is None:
        if column_type == "date":
            df = df.withColumn(partition_column, df[partition_reference].substr(1, 10))
        else:
            df = df.withColumn(partition_column, df[partition_reference].cast(StringType()))
    else:
        print("Column reference to use for p_col not given, add partition column skipped")

    return df


def add_surrogate_key(df, df_column, maxval):
    """Function to add incremental index for surrogate keys and return dataframe"""
    # add new index column name and type at end of schema to use later
    new_schema = StructType(df.schema.fields + [StructField("temp_index", LongType(), False)])
    print(new_schema)
    # call rdd function to add index, key=row, value=index
    rdd_obj = df.rdd.zipWithIndex()
    # transform key value to dictionary extracting each column from key
    rdd_dict = rdd_obj.map(lambda row_tuple:
                           ({k: v
                             for k, v in row_tuple[0].asDict().items() | [("temp_index", row_tuple[1] + maxval + 1)]}))
    # create datafarme from rdd with new schema
    rdd_df = rdd_dict.toDF(new_schema)
    # replace column with index values
    new_df = rdd_df.withColumn(df_column, rdd_df["temp_index"])
    new_df.show()
    # return with dropped temp_index
    return new_df.drop("temp_index")


def check_quality(df):
    """Data check with source dataframe"""
    # get total of pure dupes, log, then drop
    total = df.groupBy(df.columns).\
        count()\
        .where(f.col('count') > 1)\
        .select(f.sum('count').alias('total'))\
        .collect()[0]["total"]

    if total is None:
        print("no dupes!")
        return df
    else:
        print(f"Dropping Duplicates: {total}")
        return_df = df.dropDuplicates()
        return return_df


def scd2(spark,
         source_df,
         target_df,
         join_keys,
         p,
         logger,
         dw_key,
         max_val):
    """This function calculates dataframe to be upserted in SCD2 method
    Update old records, insert new"""
    print("Starting SCD2!")

    # set appcycledate var
    query = f"""select substr(cast(cycledate as string),1,10) as cd 
from {p.database}.appcycledate
where cyclecode = '{p.cyclecode}'"""
    app_cycle_df = spark.sql(query).collect()

    if len(app_cycle_df):
        cd = app_cycle_df[0]['cd']
    else:
        print(f"No app cycledate present for this job and cyclecode: {p.cyclecode}")
        sys.exit(1)

    print(f"App Cycle Date: {cd}")

    window = Window.partitionBy(*join_keys).orderBy(f.desc("dwcreatedate"))  # desc
    source_df.cache()

    # new or changed in source
    upsert_df = source_df.join(target_df, "hash", how="left_anti").select(source_df["*"])

    if len(upsert_df.head(1)) == 0:
        print("no change!")
        return None

    base_df = target_df.join(source_df, join_keys, how="left").select(target_df["*"], source_df["hash"].alias("hash_sdf"))

    # unchanged df, get records from target where hash is same or missing from source, then drop hash column
    unchanged_df = base_df \
        .where((f.col("hash") == f.col("hash_sdf")) | f.col("hash_sdf").isNull()) \
        .select(target_df["*"]).drop("hash")

    # rest of target to merge with upsert
    rest_df = base_df \
        .where((target_df["hash"] != f.col("hash_sdf")) & f.col("hash_sdf").isNotNull()) \
        .select(target_df["*"])

    # merge new and changed set with target set having same join key for updates
    # replace new record col effectiveFrom to dwcreated date
    # replace previous record col effectiveTo to dwcreated - 1
    # upsert_date=appcycledate and upsert_date_1=appcycledate-1
    merge_df = upsert_df.union(rest_df) \
        .withColumn("rownum", f.row_number().over(window)) \
        .withColumn("upsert_date", f.to_timestamp(f.to_date(f.lit(cd)))) \
        .withColumn("upsert_date_1", f.to_timestamp(f.date_add(f.to_date(f.lit(cd)), -1))) \
        .withColumn("lead_date", f.lead("dwcreatedate").over(window)) \
        .withColumn("lag_date", f.lag("dwcreatedate").over(window)) \
        .withColumn("lag_name", f.lag("dwcreatebyname").over(window)) \
        .withColumn("lag_processid", f.lag("dwcreatebyprocessid").over(window))

    print("merge df")
    merge_df.orderBy(*join_keys, f.desc("dwcreatedate")).show()

    insert_condition = (f.col("rownum") == 1)
    upsert_condition = (f.col("rownum") == 2)

    # upsert set with updated fields, unchanged set not included so conditions is applied just here
    update_df = merge_df \
        .withColumn("dweffectivefromdate", f.when(insert_condition & f.col("lead_date").isNotNull(), f.col("upsert_date"))
                    .otherwise(f.col("dweffectivefromdate"))) \
        .withColumn("dweffectivetodate", f.when(upsert_condition, f.col("upsert_date_1"))
                    .otherwise(f.col("dweffectivetodate"))) \
        .withColumn("dwupdatedate", f.when(upsert_condition, f.col("lag_date"))
                    .otherwise(f.col("dwupdatedate"))) \
        .withColumn("dwupdatebyname", f.when(upsert_condition, f.col("lag_name"))
                    .otherwise(f.col("dwupdatebyname"))) \
        .withColumn("dwupdatebyprocessid", f.when(upsert_condition, f.col("lag_processid"))
                    .otherwise(f.col("dwupdatebyprocessid")))
    # add surrogate keys only to new records
    new_df = update_df.filter(update_df[dw_key] == 0)
    new_df = add_surrogate_key(new_df, dw_key, max_val)
    old_df = update_df.filter(update_df[dw_key] > 0)

    # persist before drop columns for fidelity?
    union_df = new_df.union(old_df)
    insert_into(spark, union_df, logger, p.database, f"{p.table}_cdc", p.parent_path)
    union_df = spark.sql(f"select * from {p.database}.{p.table}_cdc")

    # merge with unchanged set and drop columns
    clean_df = union_df.drop("rownum", "upsert_date", "upsert_date_1", "lead_date", "lag_date", "lag_name", "lag_processid", "hash")
    # final_df = clean_df
    final_df = clean_df.union(unchanged_df)
    logger.warn("Done with SCD2!")
    source_df.unpersist()
    return final_df


def upsert(spark,
           source_df,
           target_df,
           join_keys,
           p,
           logger,
           dw_key = None,
           max_val = None):
    """
    Function to perform upsert logic - shared across SCD1 and fact_upsert
    """
    logger.warn("Start on upsert logic")

    # dw columns to keep values from during update
    dw_columns_create = ["dwcreatedate", "dwcreatebyname", "dwcreatebyprocessid"]

    # old records that only exist in target -- keep as is
    base_df = target_df.join(source_df, join_keys, how="left")
    unchanged_df = base_df \
        .where((target_df["hash"] == source_df["hash"]) | source_df["hash"].isNull()) \
        .select(target_df["*"])
    print("unchanged_df")
    unchanged_df.show()

    # new records from source to insert
    insert_df = source_df.join(target_df, join_keys, how="left_anti")

    # if there is a dw_key provided, account for surrogate key column
    if dw_key:
        print("Found surrogate key, using it for upsert")
        insert_df = add_surrogate_key(insert_df, dw_key, max_val)
        print("insert_df")
        insert_df.show()

        # records to update, keep original dw_key value
        source_df_update = source_df.drop(*[dw_key, *dw_columns_create])
        update_df = target_df.join(source_df_update.alias("src"), join_keys, how="inner") \
            .where(target_df["hash"] != source_df_update["hash"]) \
            .select(target_df[dw_key], *target_df[join_keys], *target_df[dw_columns_create], "src.*")
        print("update_df")
        update_df.show()
    else:
        print("No surrogate key found in upsert")
        print("insert_df")
        insert_df.show()

        # records to update, keep all column values from source except "create" dw columns
        source_df_update = source_df.drop(*dw_columns_create)       
        update_df = target_df.join(source_df_update.alias("src"), join_keys, how="inner") \
            .where(target_df["hash"] != source_df_update["hash"]) \
            .select(*target_df[join_keys], *target_df[dw_columns_create], "src.*")
        print("update_df")
        update_df.show()

    # combine all records into one aggregated df

    df_agg = unchanged_df.unionByName(insert_df).unionByName(update_df)
    insert_into(spark, df_agg, logger, p.database, f"{p.table}_cdc", p.parent_path)
    logger.warn("Done with upsert logic")
    df_agg = spark.sql(f"select * from {p.database}.{p.table}_cdc")

    return df_agg.drop("hash")


def delete_insert(spark,
                  source_df,
                  target_df,
                  join_keys,
                  p,
                  logger,
                  dw_key = None,
                  max_val = None):
    """Function to perform fact table delete-insert pattern."""

    logger.info("Begin Fact Table (Delete - Insert) Processing.")

    # Get records to delete from the target table.
    removal_df = target_df.join(source_df, join_keys, how="inner").select(target_df["*"])
    insert_into(spark, removal_df, logger, p.database, f"{p.table}_deleted", p.parent_path)

    # Get records in target table that are not deleted by the source table.
    base_df = target_df.join(source_df, join_keys, how="left_anti").select(target_df["*"])
    print("Target Records Kept:")
    base_df.show()

    # Add data warehouse key if necessary.
    if dw_key:
        insert_df = add_surrogate_key(source_df, dw_key, max_val)
    else:
        insert_df = source_df

    print("Records to Insert:")
    insert_df.show()

    # Union target records dataframe with insert dataframe.
    final_df = base_df.unionByName(insert_df)

    print(" Final Dataframe: ")
    final_df.show()

    insert_into(spark, final_df, logger, p.database, f"{p.table}_cdc", p.parent_path)

    logger.info("Finished Fact Table processing.")

    return final_df.drop("hash")


def change_data_capture(spark, source_df, target_df, p, logger):
    """common method to compare and upsert/delete target table"""
    # add column checks to columns list
    source_columns_list = [col for col in source_df.columns if not (col in p.dw_columns)]
    # join_keys = p.join_keys
    # dw_key = p.dw_key
    # cdc_type = p.cdc_type
    # increment = p.increment
    # checking conditions to see if surrogate key column is needed
    # assuming we will have a flag for has_surrogate_key = 0 if we are overriding cdc_type defaults
    has_surrogate_key = ((p.cdc_type == "scd2") | (p.increment == 1))
    print(f"The has_surrogate_key value: {has_surrogate_key}")

    check_columns = p.join_keys.copy()
    if has_surrogate_key:
        check_columns.append(p.dw_key)

    if not target_df:
        target_exists = 0
    else:
        # check if schemas match, and if join columns, dw_key, and datecreated is in schema
        # if source_df.schema != target_df.schema or \
        zip_df_schemas = zip(source_df.schema, target_df.schema)
        if not all((a.name.lower(), a.dataType) == (b.name.lower(), b.dataType) for a, b in zip_df_schemas) \
                or not all((c in source_df.columns and c in target_df.columns) for c in check_columns):
            logger.error("Schemas don't match or keys not in dataframes")
            print("Schemas don't match or keys not in dataframes!")
            sys.exit(1)
        target_exists = len(target_df.head(1))

    # if target_df is missing or empty
    if not target_exists:
        print("No records in target")
        if has_surrogate_key:
            # increment to surrogate dw_key
            load_df = add_surrogate_key(source_df, p.dw_key, 0)
        else:
            load_df = source_df
    else:
        # adds hash and flag columns
        print(f"Hash on source_columns_list:{source_columns_list}")
        s_df = source_df.withColumn("hash", f.hash(*source_columns_list))  # .withColumn("flag", lit("SOURCE_DF"))
        t_df = target_df.withColumn("hash", f.hash(*source_columns_list))  # .withColumn("flag", lit("TARGET_DF"))

        # get max value of target surrogate key
        if has_surrogate_key:
            max_key = int(t_df.groupBy().max(p.dw_key).collect()[0][f"max({p.dw_key})"])
            print(f"max_key: {max_key}")
        else:
            max_key = None
        print(f"join_keys :{p.join_keys}")
        if p.cdc_type == "scd2":
            load_df = scd2(spark, s_df, t_df, p.join_keys, p, logger, p.dw_key, max_key)
        elif p.cdc_type == "upsert" and p.increment:
            load_df = upsert(spark, s_df, t_df, p.join_keys, p, logger, p.dw_key, max_key)
        elif p.cdc_type == "upsert" and not p.increment:
            load_df = upsert(spark, s_df, t_df, p.join_keys, p, logger)
        elif (p.cdc_type == "delete_insert") and p.increment:
            load_df = delete_insert(spark, s_df, t_df, p.join_keys, p, logger, p.dw_key, max_key)
        elif (p.cdc_type == "delete_insert") and not p.increment:
            load_df = delete_insert(spark, s_df, t_df, p.join_keys, p, logger)

        else:
            logger.error("No CDC type given!")
            load_df = None

    return load_df
