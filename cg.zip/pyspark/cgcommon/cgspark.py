"""
spark.py
~~~~~~~~
Main CG Common Module containing helper function for use with Apache Spark
"""

import sys, json
from os import listdir, path
from pyspark import SparkFiles
from pyspark.sql import SparkSession

from cgcommon import logging


def table_check(spark, db, table):
    """Checks hive meta if table exists"""
    if spark._jsparkSession.catalog().tableExists(db, table):
        print(f"Table exists: {db}.{table}")
        return True
    else:
        return False


def create_external(spark, dataframe, log, db, table, location, partition_col=None):
    """Creates external table if it doesn't exists in hive metastore
    Inspired by : https://stackoverflow.com/a/49963020/435228
    """
    # check if db exists
    if table_check(spark, db, table):
        log.warn(f"Skipping create_external: {db}.{table}")
        print(f"Skipping create_external: {db}.{table}")
        return None

    print(f"Partition column: {partition_col}")
    partition_data_type = "string"  # sets default datatype for partition column p_col

    try:
        # start sql string for create statement
        print(f"Creating external table: {db}.{table}")
        buffer = list()
        buffer.append(f"CREATE EXTERNAL TABLE {db}.{table} (")
        schema_list = dataframe.dtypes
        sizeof = len(dataframe.dtypes)
        log.warn("Number of Columns: " + str(sizeof))
        count = 1
        for each in schema_list:
            print(count, sizeof, each)
            column_name = each[0]
            data_type = each[1]
            if count == 1:
                total = f"{column_name} {data_type} "
            else:
                total = f",{column_name} {data_type} "
            buffer.append(total)
            count = count + 1
        buffer.append(" ) ")
        if partition_col:
            buffer.append("PARTITIONED BY ( ")
            buffer.append(f"{partition_col} ")
            buffer.append(f"{partition_data_type}) ")
        buffer.append("STORED as parquet ")
        buffer.append("LOCATION ")
        buffer.append("'")
        buffer.append(location)
        buffer.append("'")
        table_ddl = "".join(buffer)
        log.warn(table_ddl)
        spark.sql(table_ddl)
    except Exception as e:
        log.error("Failed to create external table")
        log.error(str(e))
        print(str(e))
        sys.exit(1)

    return None


def start_spark(app_name="pyspark_job"
                , master="yarn"
                , jars=[]
                , files=[]
                , spark_conf={}):
    """Start Spark Session, logger, loads config files"""
    spark_builder = (SparkSession.builder
                     .master(master)
                     .appName(app_name))

    # apply jars to builder
    if jars:
        jars_list = ','.join(jars)
        spark_builder.config('spark.jars', jars_list)

    # list of files to be place in working dir of each executor
    if files:
        files_list = ','.join(files)
        spark_builder.config('spark.files', files_list)

    # add other config params
    if spark_conf:
        for key, val in spark_conf.items():
            spark_builder.config(key, val)

    # create session and logger
    spark_session = spark_builder.getOrCreate()
    spark_logger = logging.Log4j(spark_session)

    # load config to dict if submitted with --files, need files argument passed in
    spark_files_dir = SparkFiles.getRootDirectory()
    conf_file = [filename
                 for filename in listdir(spark_files_dir)
                 if filename.endswith(".json")]
    if len(conf_file) > 0:
        # creates path of conf file in cluster
        path_to_conf_file = path.join(spark_files_dir, conf_file[0])
        with open(path_to_conf_file, "r") as read_conf_file:
            # lower case all keys and values in json
            conf_dict = json.loads(str(read_conf_file.read()).lower())
        spark_logger.warn("loading config from " + conf_file[0])
    else:
        spark_logger.warn("no config file found")
        conf_dict = {}  # None

    return spark_session, spark_logger, conf_dict


def get_query(spark_logger, query_file):
    """Function to get query string from query file submitted with the job py"""
    print(query_file)
    spark_files_dir = SparkFiles.getRootDirectory()
    sql_file = [sql_filename for sql_filename in listdir(spark_files_dir)
                if sql_filename == query_file][0]
    if sql_file:
        path_to_sql_file = path.join(spark_files_dir, sql_file)
        with open(path_to_sql_file, "r") as read_sql_file:
            sql_query_str = str(read_sql_file.read())
        spark_logger.warn(f"Loading sql from {sql_file}")
    else:
        spark_logger.warn("No sql file found")
        return None

    return sql_query_str


def get_filenames():
    """Helper function to get list of files from argument passsed in with spark_submit.sh"""
    # Set list of files
    if len(sys.argv) > 1:
        file_list_with_path = sys.argv[1].split(",")
        print(file_list_with_path)
        # Get the name of file from path given in args
        file_list = [f.split("/")[-1] for f in file_list_with_path]
    else:
        file_list = []

    print(f"Files included in this job: {file_list}")
    return file_list
