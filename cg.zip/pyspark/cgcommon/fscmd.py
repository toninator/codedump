"""
fscmd.py 
 python3.6 /home/shbr/fscmd.py "-ls ./" "hdfs"
"""

import sys
import shlex
from subprocess import PIPE, Popen, run
import traceback


def exec_cmd(cmd):
    try:
        cmdToExec = run(shlex.split(cmd), stderr=PIPE, stdout=PIPE, universal_newlines=True)
        rc = cmdToExec.returncode
        if rc == 0:
            print(f"Command Executed successfully : {cmd}")
            print(cmdToExec.stdout)
        else:
            print(f'\nCommand Execution failed : {cmd} \n {cmdToExec.stderr} {cmdToExec.stdout}')
    except Exception as e:
        print(traceback.print_exc())
        sys.exit(1)
    return rc


def fscmd(cmd, platform="hdfs"):
    platform = platform.lower().strip()
    cmd = cmd.lower().strip()
    if len(cmd) > 0 and len(platform) > 0:
        if platform == "hdfs":
            result = exec_cmd("hdfs dfs " + cmd)
        elif platform == "dbfs":
            print(f"{platform} operations are not implemented")
        else:
            print("Please verify the platform value passed is accurate")
    else:
        print("No command/platform passed to execute")
    return result

def main():
    print('Number of arguments:', len(sys.argv), 'arguments.')
    print('Argument List:', str(sys.argv))
    if len(sys.argv) == 3:
        fscmd(sys.argv[1], sys.argv[2])
    elif len(sys.argv) == 2:
        fscmd(sys.argv[1], "hdfs")
    else:
        print("Please provide the 2 arguments: cmd & platform")

    return None


if __name__ == '__main__':
    main()
