"""
params.py
~~~~~~~~~
Module that defiles the Conf class to construct parameter object to pass through functions
"""


class Conf(object):
    def __init__(self, config):
        """ Initialize all the default parameters used in *most* pipeline jobs
        https://stackoverflow.com/a/2466207/435228
        """

        self.load_sql_required = ["database",
                                  "table",
                                  "parent_path",
                                  "join_keys",
                                  "dw_key",
                                  "cdc_type",
                                  "query_file"]
        self.file_publication_required = ["interface_name", "target_loc", "query_file"]
        self.appcycle_update_required = ["database",
                                         "table",
                                         "parent_path",
                                         "cyclecode",
                                         "partition_column",
                                         "appid",
                                         "appname"]
        self.optional_keys = ["increment", "partition_column"]
        self.config_keys = list(config.keys())

        total_keys = self.load_sql_required + self.optional_keys \
            + self.config_keys \
            + self.file_publication_required \
            + self.appcycle_update_required

        # dedupe attribute keys
        keys = set(total_keys)

        for key in keys:
            if type(config.get(key)) is str:
                setattr(self, key.lower(), config.get(key).lower())
            else:
                setattr(self, key.lower(), config.get(key))

        # should be a list to handle more than 1 audit or join columns
        if type(self.join_keys) is str:
            self.join_keys = [self.join_keys]
        elif type(self.join_keys) is list:
            self.join_keys = [str(jk).lower() for jk in self.join_keys]

        # get the warehouse surrogate key
        if self.table and not self.dw_key:
            self.dw_key = f"dw{self.table}id"

        # set partition_column if exists in json config
        if self.partition_column:
            # p_col should be standard
            self.part_col = "p_col"
        else:
            self.part_col = ""
            self.partition_column = {}
        self.partition_reference = self.partition_column.get("name")
        self.partition_type = self.partition_column.get("type")
        self.partition_filter = self.partition_column.get("filter")

        # dw column list
        self.dw_columns = ["dwcreatedate",
                           "dwcreatebyname",
                           "dwcreatebyprocessid",
                           "dwupdatedate",
                           "dwupdatebyname",
                           "dwupdatebyprocessid",
                           "dwversion",
                           "dwsourcesystemcode",
                           "dweffectivefromdate",
                           "dweffectivetodate",
                           "p_col",
                           self.dw_key]

    def check_params(self, job_type):
        check = True
        if job_type == "load_sql":
            # check if any required keys are not set
            if not all(getattr(self, k) for k in self.load_sql_required):
                print("JSON Missing required attributes!")
                print(*[k for k in self.load_sql_required if not getattr(self, k)], sep = ", ")
                check = False
        elif job_type == "file_publication":
            if not all(getattr(self, k) for k in self.file_publication_required):
                print("JSON Missing required attributes!")
                print(*[k for k in self.file_publication_required if not getattr(self, k)], sep = ", ")
                check = False
        elif job_type == "appcycle_update":
            if not (all(getattr(self, k) for k in self.appcycle_update_required) and self.partition_reference):
                print("JSON Missing required attributes!")
                print(*[k for k in self.appcycle_update_required if not getattr(self, k)], sep = ", ")
                if not self.partition_reference:
                    print("Missing partition_column name")
                check = False
        else:
            print("No job_type matched in check_params()")
            return False
       
        return check
