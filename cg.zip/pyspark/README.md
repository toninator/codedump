# CG PySpark  
Capital Group's LASRIM PySpark ETL component
https://confluence.capgroup.com/display/LASRIM/LASRIM+PySpark+Project+-+AllSpark

## ETL Project Structure

```bash
pyspark/
 |-- cgcommon/
     |-- logging.py
     |-- cgspark.py
     |-- compare.py
 |-- conf/
     |-- spark_config.json
 }-- jars/
     |-- xml.jar
 |-- jobs/
     |-- target_database
         |-- table1
             |-- table1.py
             |-- query.sql
             |-- table1.json
 |-- spark_submit.sh
 |-- zip_cgcommon.sh

```

## Dependencies

- Python3 Virtual Environment
  - This runner is dependent on a python3 virtual environment on host, and its archive.
  - Steps to create python3 venv archive
    - Locate python3 bin
    - pip install pyvenv if not already installed
    - pyvenv <target_path>/py3
    - zip -r py3.zip py3 &>> zip.log
- spark2-submit and hadoop binaries 
- Could make this a separate post install process to create virtualenv and zip arch for spark_submit.sh
    
## spark_submit.sh

This is the wrapper shell script to call in autosys.

- Executes spark2-submit binary
- Sets the python venv zip as pyspark_python version
- Deploys job to cluster
- Send cgcommon.zip as --py-files to reference in job
- Takes 2 arguments
  - The path of the py job file
  - The path of the json and query files, **MUST BE DELIMITED BY COMMAS**
- Will avoid adding spark configs here and handle it in the spark builder
- Example command in Autosys
>./spark-submit.sh jobs/im_pz_fibmr_s/LUXShrHldrBMRAccountReferenceDataOverwrite.py conf/im_pz_fibmr_s/LUX/dev.json,conf/im_pz_fibmr_s/LUX/query.sql



## Jobs

This directory contains all py job files for etl

- Folders are organized by target database in prepared zone
- File names map to the target table 


## Confs

This directory hosts the custom configs specific to the job if necessary

- Folders are organized by target database in prepared zone
- File names map to the target table 
- Spark config jsons will be available to set during start_spark builder. Could have different configs for different jobs depending volume, parallelism,  and shuffle 


## CGCommon

This is our common library to customize and utilize for repeatable operations

- Example: logging, create_external, etc.
- If pipelines have need for separate modules that's specific to the etl job, devs can drop them in jobs/db/table dir and import them in using --py-files= separated by commas
- If the module is not widely used, should not be hosted in cgcommon
  

## Temporary development instructions

Instructions on how to get started on development:
- ssh to x773677
- cd /tmp/pyspark (temporary component location)
- make directory for your target database under jobs and conf directories
- copy LUXShrHldrBMRAccountReferenceDataOverwrite.py and json from jobs/im_pz_fibmr_s and conf/im_pz_fibmr_s
- modify to your logic and parameters, you can use vi or nano or just copy and paste from your local editor 
- For now, the external tables will be created in tnzs hive database, but the storage path should point to azure.
- Run the pyspark component running the spark-submit.sh
`./spark-submit.sh jobs/im_pz_fibmr_s/LUXShrHldrBMRAccountReferenceDataOverwrite.py conf/im_pz_fibmr_s/LUXShrHldrBMRAccountReferenceDataOverwrite.json`
- Check if tables exists in HUE, query hive
- You can leave all the jobs and confs in the same dir, I will zip it up and check it in to the repo regularly 
- Get on pyspark2 shell
`PYSPARK_PYTHON=/users/python/python36/bin/python3 pyspark2`
- If you get Kerberos errors, run klist and kinit, this sets a token for you to access Spark
```
x773677> klist
klist: No credentials cache found (ticket cache FILE:/tmp/krb5cc_cdc16819_2l5Twf)
x773677> kinit
Password for tnzs@CGUSER.CAPGROUP.COM: 
x773677> klist
Ticket cache: FILE:/tmp/krb5cc_cdc16819_2l5Twf
Default principal: tnzs@CGUSER.CAPGROUP.COM
Valid starting     Expires            Service principal
01/31/20 14:57:43  02/01/20 00:57:59  krbtgt/CGUSER.CAPGROUP.COM@CGUSER.CAPGROUP.COM
renew until 02/01/20 14:57:43
```

- HUE: https://x252400.cguser.capgroup.com:8888/hue/editor?editor=19941
- Yarn: https://x710741.cguser.capgroup.com:8090/cluster

## To Do
- SLM
- integrate to splunk logging
 
 
Inspired by 
https://alexioannides.com/2019/07/28/best-practices-for-pyspark-etl-projects/