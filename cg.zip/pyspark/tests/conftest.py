
from pathlib import Path, WindowsPath, PosixPath
from tools.autoconf import load
import os
from time import sleep

load()

import shutil
import pytest
from pyspark.sql import SparkSession
import pyspark

from cgcommon import logging

@pytest.fixture(scope="session")
def spark_session():
    spark_session = SparkSession.builder \
        .master("local") \
        .appName("test") \
        .enableHiveSupport() \
        .getOrCreate()

    yield spark_session

    # teardown
    print("Tearing Down spark session...")
    spark_session.stop()


@pytest.fixture(scope="session")
def db(spark_session):
    db_name = "test"
    try:
        spark_session.sql(f"create database {db_name}")
    except pyspark.sql.utils.AnalysisException as e:
        if "org.apache.hadoop.hive.metastore.api.AlreadyExistsException" in str(e):
            print(e)
            raise Exception(f"Database {db_name} already exists... will not run tests until removed")
        raise e
    
    yield db_name

    # teardown
    print(f"Dropping Database {db_name}")
    spark_session.sql(f"drop database if exists {db_name} cascade")


@pytest.fixture(scope="session")
def logger(spark_session):
    logger = logging.Log4j(spark_session)
    return logger

# @pytest.fixture(scope="session", autouse=True) # TODO: Defer this usage until windows cleanup can be fixed
def clean_fs():
    hive_metastore = Path("metastore_db")
    hive_db = Path("spark-warehouse")
    hive_log = Path("derby.log")
    tmp_storage = Path("tmp")

    if hive_metastore.exists() or hive_db.exists() or hive_log.exists() or tmp_storage.exists():
        raise Exception(f"Please remove {hive_metastore}, {hive_db}, {tmp_storage}, and {hive_log} from current working directory.")
    
    yield

    # teardown
    sleep(5)
    print("Cleaning Local Filesystem")
    shutil.rmtree(tmp_storage)
    shutil.rmtree(hive_db)
    if isinstance(p, PosixPath): # TODO: Remove this after figuring out windows thing
        hive_log.unlink() # on windows these wont unbind gracefully
        shutil.rmtree(hive_metastore) # on windows these wont unbind gracefully
    else:
        print(f"Please manually remove {hive_log}, {hive_metastore}")
