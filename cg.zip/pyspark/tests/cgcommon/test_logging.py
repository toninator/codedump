import pytest
from cgcommon import logging

# untestable AFAIK