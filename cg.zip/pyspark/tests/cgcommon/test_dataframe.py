import pytest
from cgcommon import dataframe, params, cgspark
import pyspark.sql.functions as f



################## HELPERS ###################

from pandas.testing import assert_frame_equal

def assert_frame_equal_with_sort(results, expected, keycolumns):
    results_sorted = results.sort_values(by=keycolumns).reset_index(drop=True)
    expected_sorted = expected.sort_values(by=keycolumns).reset_index(drop=True)
    assert_frame_equal(results_sorted, expected_sorted)


################## SETUP ###################

@pytest.fixture(scope="module")
def mocked_conf():
    config = {
        "parent_path": "",
        "database": "",
        "table": "",
        "cdc_type": "",
        "join_keys": [""],
        "query_file": "",
        "partition_column": {
            "name": "dweffectivetodate",
            "type": "date",
            "filter": "9999-12-31"},
        "cyclecode": ""
    }
    c = params.Conf(config)
    return c

@pytest.fixture(scope="module")
def mocked_df(spark_session):
    df = spark_session.read.csv("tests/samples/mocked_dataframe.csv", header=True)
    return df


@pytest.fixture(scope="module")
def mocked_dupes_df(spark_session):
    df =  spark_session.read.csv("tests/samples/mocked_dataframe_dupes.csv", header=True)
    return df


################## TESTS ###################

def test_extract_compare_set_no_table(spark_session, db):
    out = dataframe.extract_compare_set(spark_session, db, "not_found")
    assert out == None, "No Table Found in Hive"


@pytest.mark.skip(reason="Covered in test_insert_into_with_partition")
def test_extract_compare_set_partition():
    pass # See test_insert_into_with_partition


@pytest.mark.skip(reason="Covered in test_insert_into")
def test_extract_compare_set_no_partition(spark_session):
    pass # See test_insert_into
    

def test_insert_into(spark_session, db, logger, mocked_df):
    dataframe.insert_into(spark_session, mocked_df, logger, db, "test_insert_into", "tmp")
    count = spark_session.sql(f"select count(1) as cnt from {db}.test_insert_into")
    assert mocked_df.count() == count.collect()[0].cnt, "Hive matches dataframe count"


@pytest.mark.skip(reason="TODO: havent looked.")
def test_insert_into_with_partition(spark_session, db, logger, mocked_df):
    raise NotImplementedError()


def test_add_dw_columns(mocked_df, mocked_conf):
    result = dataframe.add_dw_columns(mocked_df, mocked_conf)
    dw_cols = set([
        ('dwcreatedate', 'timestamp'), 
        ('dwcreatebyname', 'string'), 
        ('dwcreatebyprocessid', 'bigint'), 
        ('dwupdatedate', 'timestamp'), 
        ('dwupdatebyname', 'string'), 
        ('dwupdatebyprocessid', 'bigint'), 
        ('dwversion', 'int'), 
        ('dwsourcesystemcode', 'string')
    ])
    assert dw_cols.issubset(result.dtypes), "DW Columns Added"


@pytest.mark.skip(reason="havent looked yet...")
def test_add_partition_column(mocked_df):
    #dataframe.add_partition_column(mocked_df, partition_column, partition_reference, column_type="date")
    raise NotImplementedError()


def test_add_surrogate_key(mocked_df):
    sk_offset = 100
    df_out = dataframe.add_surrogate_key(mocked_df, "sk", sk_offset)
    max_sk_ref = sk_offset + mocked_df.count()
    max_sk = df_out.select(f.max(f.col("sk")).alias("MAX")).limit(1).collect()[0].MAX
    assert max_sk_ref == max_sk, "Surrogate Key Added as sk with max value"


def test_check_quality_no_dupes(mocked_df):
    cleaned = dataframe.check_quality(mocked_df)
    assert cleaned == mocked_df, "Dataset is Unique"


def test_check_quality_dupes(spark_session, mocked_df, mocked_dupes_df):
    cleaned = dataframe.check_quality(mocked_dupes_df)
    assert cleaned.count() != mocked_dupes_df.count()
    assert_frame_equal_with_sort(cleaned.toPandas(), mocked_df.toPandas(), [t[0] for t in mocked_dupes_df.dtypes])


@pytest.mark.skip(reason="havent looked yet...")
def test_scd2(mocked_df):
    #dataframe.scd2
    raise NotImplementedError()


@pytest.mark.skip(reason="havent looked yet...")
def test_upsert(mocked_df):
    #dataframe.upsert
    raise NotImplementedError()


@pytest.mark.skip(reason="havent looked yet...")
def test_change_data_capture(mocked_df):
    #dataframe.upsert
    raise NotImplementedError()
