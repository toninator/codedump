import pytest
from cgcommon import cgspark, params

@pytest.fixture(scope="module")
def mocked_df(spark_session):
    df = spark_session.read.csv("tests/samples/mocked_dataframe.csv", header=True)
    return df



################## TESTS #####################

def test_table_check_not_exist(spark_session, db):
    out = cgspark.table_check(spark_session, db, "test_table_check_not_exist")
    assert out == False, "Table doesn't exist"


# this also tests test_table_check_exist condition
def test_create_external(spark_session, db, logger, mocked_df):
    cgspark.create_external(spark_session, mocked_df, logger, db, "test_create_external", f"tmp/{db}/test_create_external")
    out = cgspark.table_check(spark_session, db, "test_create_external")
    assert out == True, "Table Created"