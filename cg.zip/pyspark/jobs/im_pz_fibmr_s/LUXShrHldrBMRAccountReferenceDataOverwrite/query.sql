select
coalesce(CAST(UD.AccountNumber AS varchar(30)), 'Unknown') AS AccountNumber,
coalesce(CAST(UD.AccountNameCMPS AS varchar(200)), 'Unknown') AS AccountName,
coalesce(CAST(UD.SummaryAccountTypeBMR AS varchar(200)), 'Unknown') AS SummaryAccountType,
coalesce(CAST(UD.AccountSubTypeBMR AS varchar(200)), 'Unknown') AS AccountSubType,
coalesce(CAST(UD.VehicleTypeBMR AS varchar(30)), 'Unknown') AS VehicleType,
coalesce(CAST(UD.ActiveFlagBMR AS varchar(1)), 'U') AS ActiveFlag,
CAST (UD.AccountAliasesBMR AS varchar(30)) AS AccountAliases,
CAST (UD.VehicleGroupingBMR AS varchar(60)) AS VehicleGrouping,
CAST (UD.MorningstarLUXFundNameBMR AS varchar(100)) AS MorningstarLUXFundName,
coalesce(CAST(UD.SummaryFIMandateBMR AS varchar(255)), 'Unknown') AS SummaryFIMandate,
coalesce(CAST(UD.DetailedFIMandateBMR AS varchar(255)), 'Unknown') AS DetailedFIMandate,
coalesce(CAST(UD.AccountCategoryBMR AS varchar(50)), 'Unknown') AS AccountCategory,
coalesce(CAST(UD.AUMBeginDateBMR AS timestamp), cast('1900-01-01' as timestamp)) AS AUMBeginDate,
coalesce(CAST(UD.AUMEndDateBMR AS timestamp), cast('1900-01-01' as timestamp)) AS AUMEndDate,
coalesce(CAST(UD.AccountTypeBMR AS varchar(200)), 'Unknown') AS AccountType,
coalesce(CAST(UD.AccountMandateBMR AS varchar(255)), 'Unknown') AS AccountMandate,
CAST(UD.TaxExemptFlagBMR AS varchar(1)) AS TaxExemptFlag,
CAST (UD.AccountExclusionFlagBMR AS varchar(1)) AS AccountExclusionFlag,
CAST (UD.PlanTypeDescriptionSFDC AS varchar(30)) AS PlanTypeDescription,
CAST (UD.PlanDefinerDescriptionSFDC AS varchar(30)) AS PlanDefinerDescription,
coalesce(CAST(UD.SourceLastModByBMR AS varchar(10)), 'Unknown') AS SourceLastModBy,
CAST(UD.Reserved0 AS varchar(200)) AS Reserved_Col0,
CAST(UD.Reserved1 AS varchar(200)) AS Reserved_Col1,
CAST(UD.Reserved2 AS varchar(200)) AS Reserved_Col2,
CAST(UD.Reserved3 AS varchar(200)) AS Reserved_Col3,
CAST(UD.Reserved4 AS varchar(200)) AS Reserved_Col4,
CAST(UD.Reserved5 AS varchar(200)) AS Reserved_Col5,
CAST(UD.Reserved6 AS varchar(200)) AS Reserved_Col6,
CAST(UD.Reserved7 AS varchar(200)) AS Reserved_Col7,
CAST(UD.Reserved8 AS varchar(200)) AS Reserved_Col8,
/* CAST(UD.Reserved8 AS varchar(200)) AS Reserved_Col8, */
CAST(UD.Reserved9 AS varchar(200)) AS Reserved_Col9
from im_sz_fibmr_s.isg_bmr_ui_reverse_feed_data_full_f1_v1_t1_current ud
join (
    select cycledate as cd
    from im_pz_fibmr_ns.appcycledate
    where cyclecode ='im-bmr') acd on 1= 1
left join im_pz_portfoliopos_s.cgportfolio cp
on ud.PortfolioUniqueIdentifier = cp.PortfolioUID
and cp.investmentportfoliotypecode = 'AA'
where acd.cd between cp.dweffectivefromdate and cp.dweffectivetodate
--and ud.portfoliouniqueidentifier is null
