SELECT
coalesce(CAST(c.DWCGPortfolioID AS bigint),-9999999999) AS DWCGPortfolioID,
coalesce(CAST(c.PortfolioUID AS bigint),-9999999999) AS PortfolioUID,
coalesce(CAST(c.InvestmentAccountUID AS bigint),-9999999999) AS InvestmentAccountUID,
coalesce(CAST(a.AccountNumber AS int),-9999) AS AccountNumber,
coalesce(CAST(a.TradeDate AS TIMESTAMP), timestamp('01-01-1900')) AS CashFlowReportDate,
CAST(a.CashFlow AS decimal(28,8)) AS CashFlowAmount,
CAST(a.Mandate AS varchar(150)) AS MandateDescription,
CAST(a.PortType AS varchar(50)) AS PortfolioTypeDescription
FROM IM_pz_PCS_S.pcsficashflowmonthend a
INNER JOIN im_pz_acctpostrans_s.investmentaccount b
ON a.AccountNumber = b.InvestmentAccountNumber
INNER JOIN IM_pz_PORTFOLIOPOS_S.cgportfolio c
ON b.InvestmentAccountUID = c.InvestmentAccountUID
where a.TradeDate BETWEEN c.DWEffectiveFromDate and c.DWEffectiveToDate
and a.TradeDate BETWEEN  b.DWEffectivefromDate and b.DWEffectiveToDate
and c.InvestmentPortfolioTypeCode = 'AA'