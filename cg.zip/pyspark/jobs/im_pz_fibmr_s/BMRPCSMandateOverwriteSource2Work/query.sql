SELECT
COALESCE(CAST(pmo.ManagerInitials AS VARCHAR(10)),'Unknown') AS ManagerInitials,
CAST(pmo.SummaryFIMandate AS VARCHAR(255)) AS SummaryFIMandate,
CAST(pmo.DetailedFIMandate AS VARCHAR(255)) AS DetailedFIMandate,
CAST(pmo.LastModBySource AS VARCHAR(10)) AS LastModBySource,
CAST(pmo.LastModDateSource AS timestamp) AS LastModDateSource
FROM im_sz_fibmr_s.isg_bmr_ui_pcs_mandate_reverse_feed_data_full_f1_v1_t1_current pmo