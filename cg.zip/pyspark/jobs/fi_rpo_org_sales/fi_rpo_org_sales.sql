WITH US_HOLIDAY AS 
( 
       SELECT CG_US_HOLDY_IND 
       FROM   PREPARE_DW.CALENDAR 
       WHERE  DATE_FORMAT(CLNDR_DT, 'YYYY-MM-DD') = CURRENT_DATE), PARAM_TEMP AS 
( 
         SELECT   MIN(C.YR_MO_NUM)     QTR_1_MNTH, 
                  MIN(C.YR_MO_NUM) + 1 QTR_2_MNTH, 
                  MAX(C.YR_MO_NUM)     QTR_3_MNTH, 
                  WK_RUN_DT, 
                  CURR_MNTH, 
                  CURR_YR, 
                  PREV_YR, 
                  PREV_2_YR, 
                  PREV_QTR, 
                  PREV_MNTH, 
                  BEGIN_MNTH, 
                  END_MNTH, 
                  LYTD_MNTH 
         FROM     PREPARE_DW.CALENDAR C 
         JOIN 
                  ( 
                         SELECT WK_RUN_DT, 
                                INT(DATE_FORMAT(TO_DATE(WK_RUN_DT), 'YYYYMM'))                 CURR_MNTH,
                                YEAR(WK_RUN_DT)                                                AS CURR_YR,
                                YEAR(ADD_MONTHS(TO_DATE(WK_RUN_DT), -12))                      AS PREV_YR,
                                YEAR(ADD_MONTHS(TO_DATE(WK_RUN_DT), -24))                      AS PREV_2_YR,
                                ( ( INT((MONTH(TO_DATE(WK_RUN_DT))-1)/3) + 1 ) - 1 )           AS PREV_QTR,
                                DATE_FORMAT(ADD_MONTHS(TO_DATE(WK_RUN_DT), -1), 'YYYYMM' )     AS PREV_MNTH,
                                       CONCAT(YEAR(ADD_MONTHS(TO_DATE(WK_RUN_DT), -24)), '01') AS BEGIN_MNTH ,
                                SUBSTR(DATE_FORMAT(WK_RUN_DT , 'YYYYMMDD'), 1, 6)              AS END_MNTH,
                                DATE_FORMAT(ADD_MONTHS(TO_DATE(WK_RUN_DT), -12),'YYYYMM')      AS LYTD_MNTH,
                                CASE WHEN ( ( INT((MONTH(TO_DATE(WK_RUN_DT))-1)/3) + 1 ) - 1 ) = 0 THEN YEAR( ADD_MONTHS(TO_DATE(WK_RUN_DT), -12))
                                     ELSE YEAR(WK_RUN_DT) 
                                END P_CLNDR_YR_NUM, 
                                CASE WHEN(( INT((MONTH(TO_DATE(WK_RUN_DT))-1)/3) + 1 ) - 1 ) = 0 THEN 4
                                     ELSE (( INT((MONTH(TO_DATE(WK_RUN_DT))-1)/3) + 1 ) - 1 )
                                END P_CLNDR_QTR_NUM 
                         FROM   ( 
                                   SELECT  CASE  WHEN US_HOLIDAY.CG_US_HOLDY_IND = 'Y' AND  DAY(CURRENT_DATE) = 6 THEN STRING( DATE_FORMAT(CURRENT_DATE, 'YYYY-MM-DD')) 
                                                 WHEN DAY(PRMTR_VALUE_DATE) >= 6 THEN STRING( DATE_FORMAT(PRMTR_VALUE_DATE, 'YYYY-MM-DD')) 
                                                 WHEN DAY(PRMTR_VALUE_DATE) < 6 THEN STRING( DATE_FORMAT(NEXT_DAY(DATE_ADD( PRMTR_VALUE_DATE, -7), 'FRIDAY'), 'YYYY-MM-DD')) 
                                           END WK_RUN_DT 
                                   FROM       PREPARE_INT.ETL_CONFIG 
                                   CROSS JOIN ( SELECT CG_US_HOLDY_IND 
                                                FROM   PREPARE_DW.CALENDAR 
                                                WHERE  DATE_FORMAT(CLNDR_DT, 'YYYY-MM-DD') = CURRENT_DATE) US_HOLIDAY 
                                   WHERE      PRMTR_NAME = 'CURRENT_DAILY_CYCLE_DATE') X ) PARAMS
         ON       C.CLNDR_YR_NUM = PARAMS.P_CLNDR_YR_NUM 
         AND      C.CLNDR_QTR_NUM = PARAMS.P_CLNDR_QTR_NUM 
         GROUP BY WK_RUN_DT, 
                  CURR_MNTH, 
                  CURR_YR, 
                  PREV_YR, 
                  PREV_2_YR, 
                  PREV_QTR, 
                  PREV_MNTH, 
                  BEGIN_MNTH, 
                  END_MNTH, 
                  LYTD_MNTH),
				   
ITM_FI_RPO_ORG_SALES AS 
( 
         SELECT 
                  /*+ BROADCAST(PARAM_TEMP) */ 
                  FT.FINCL_ITRMY_PRSON_ID      FINCL_ITRMY_PRSON_ID, 
                  FT.CLRD_THRU_ORG_ID          CLRD_THRU_ORG_ID, 
                  FT.CRDTD_TO_ORG_ID           CRDTD_TO_ORG_ID, 
                  FT.CRDTD_TO_OFFC_ID          CRDTD_TO_OFFC_ID, 
                  STRING(FT.INVSR_ACCT_TYP_CD) INVSR_ACCT_TYP_CD, 
                  FT.RPC_COMBL_IND             RPC_TRD_IND, 
                  SUM( 
				  CASE 
                           WHEN FT.STTLD_DT >= DATE_ADD(TO_DATE( PARAM_TEMP.WK_RUN_DT), -4) 
                           AND      FT.STTLD_DT <= TO_DATE( PARAM_TEMP.WK_RUN_DT) THEN FT.SLS_AMT
                           ELSE 0 
				  END) LAST_WK_SLS_AMT, 
                  SUM(( FT.SLS_AMT ) * ( 
                  CASE 
                           WHEN FT.MO_NUM = PARAM_TEMP.PREV_MNTH THEN 1 
                           ELSE 0 
                  END )) LAST_MO_SLS_AMT, 
                  SUM(( FT.SLS_AMT ) * ( 
                  CASE 
                           WHEN FT.MO_NUM IN ( PARAM_TEMP.QTR_1_MNTH, 
                                              PARAM_TEMP.QTR_2_MNTH, 
                                              PARAM_TEMP.QTR_3_MNTH ) THEN 1 
                           ELSE 0 
                  END )) LAST_QTR_SLS_AMT, 
                  SUM(( FT.SLS_AMT ) * ( 
                  CASE 
                           WHEN STRING(SIGN(PARAM_TEMP.LYTD_MNTH - REPLACE(FT.MO_NUM, PARAM_TEMP.PREV_2_YR, 3000))) IN ( 1, 0 ) THEN 1
                           ELSE 0 
                  END )) LAST_YTD_SLS_AMT, 
                  SUM(( FT.SLS_AMT ) * ( 
                  CASE 
                           WHEN SUBSTR(STRING(FT.MO_NUM), 1, 4) = PARAM_TEMP.PREV_YR THEN 1 
                           ELSE 0 
                  END )) LAST_YR_SLS_AMT, 
                  SUM(( FT.SLS_AMT ) * ( 
                  CASE 
                           WHEN SUBSTR(STRING(FT.MO_NUM), 1, 4) = PARAM_TEMP.PREV_2_YR THEN 1 
                           ELSE 0 
                  END )) LAST_YR2_SLS_AMT, 
                  SUM(( FT.SLS_AMT ) * ( 
                  CASE 
                           WHEN SUBSTR(STRING(FT.MO_NUM), 1, 4) = PARAM_TEMP.CURR_YR THEN 1 
                           ELSE 0 
                  END )) YTD_SLS_AMT, 
                  SUM(( FT.SLS_AMT ) * ( 
                  CASE 
                           WHEN FT.MO_NUM = PARAM_TEMP.CURR_MNTH THEN 1 
                           ELSE 0 
                  END )) MTD_SALES_AMT, 
                  SUM( 
                  CASE 
                           WHEN FT.MO_NUM >= PARAM_TEMP.LYTD_MNTH 
                           AND      FT.MO_NUM < PARAM_TEMP.CURR_MNTH THEN FT.SLS_AMT 
                           ELSE 0 
                  END) SALES_R12 
         FROM     PREPARE_DW.FINANCIAL_TRANSACTION_CURRENT FT 
         JOIN     PARAM_TEMP 
         ON       1 = 1 
         WHERE    FT.MO_NUM >= PARAM_TEMP.BEGIN_MNTH 
         AND      FT.MO_NUM <= PARAM_TEMP.END_MNTH 
         AND      FT.RPT_SET_CD = 105 
         AND      FT.STTLD_FINCL_TXN_IND = 'Y' 
         GROUP BY FT.FINCL_ITRMY_PRSON_ID, 
                  FT.CLRD_THRU_ORG_ID, 
                  FT.CRDTD_TO_ORG_ID, 
                  FT.CRDTD_TO_OFFC_ID, 
                  FT.INVSR_ACCT_TYP_CD, 
                  FT.RPC_COMBL_IND)
				  
SELECT ORG_VW.SRC_ORG_ID                INTRNL_DLR_NUM, 
       OFFC_DIM.OFFC_BOR_NUM            OFFC_ID, 
       PRSON_DIM.FINCL_ITRMY_PRSON_UID  AE_SEQ_NUM, 
       ORG_VW.PARNT_FINCL_ITRMY_ORG_NUM NETWRK_NUM, 
       ORG_VW_2.SRC_ORG_ID              PLATFORM_DLR_NUM, 
       FIOS.RPC_TRD_IND                 RPC_TRD_IND, 
       FIOS.LAST_WK_SLS_AMT             LAST_WK_SLS_AMT, 
       FIOS.LAST_MO_SLS_AMT             LAST_MO_SLS_AMT, 
       FIOS.LAST_QTR_SLS_AMT            LAST_QTR_SLS_AMT, 
       FIOS.LAST_YR_SLS_AMT             LAST_YR_SLS_AMT, 
       FIOS.LAST_YR2_SLS_AMT            LAST_YR2_SLS_AMT, 
       FIOS.MTD_SALES_AMT               MTD_SALES_AMT, 
       FIOS.YTD_SLS_AMT                 YTD_SLS_AMT, 
       FIOS.LAST_YTD_SLS_AMT            LAST_YTD_SLS_AMT, 
       FIOS.SALES_R12                   SALES_R12 
FROM   ITM_FI_RPO_ORG_SALES FIOS, 
       PREPARE_DW.FINCL_ITRMY_PERSON_DIM PRSON_DIM, 
       PREPARE_DW.FINCL_ITRMY_ORG_VW ORG_VW, 
       PREPARE_DW.FINCL_ITRMY_ORG_VW ORG_VW_2, 
       PREPARE_DW.FINCL_ITRMY_OFFICE_DIM OFFC_DIM, 
       PREPARE_DW.LINE_OF_BUSINESS_HIERARCHY_DIM LOB_DIM 
WHERE  FIOS.FINCL_ITRMY_PRSON_ID = PRSON_DIM.FINCL_ITRMY_PRSON_ID 
       AND FIOS.CRDTD_TO_ORG_ID = ORG_VW.FINCL_ITRMY_ORG_ID 
       AND FIOS.CRDTD_TO_OFFC_ID = OFFC_DIM.FINCL_ITRMY_OFFC_ID 
       AND FIOS.CLRD_THRU_ORG_ID = ORG_VW_2.FINCL_ITRMY_ORG_ID 
       AND FIOS.INVSR_ACCT_TYP_CD = LOB_DIM.INVSR_ACCT_TYP_CD 