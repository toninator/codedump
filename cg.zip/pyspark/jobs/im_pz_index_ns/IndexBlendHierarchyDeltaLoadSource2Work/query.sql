SELECT
cast(ParentIndexVariantUid as bigint) as ParentIndexVariantPortfolioUid 
,cast(ChildIndexVariantUid as bigint) as ChildIndexVariantPortfolioUid
,cast(IndexMemberWeightStartDate as timestamp) as IndexMemberWeightStartDate
,cast(IndexMemberWeightEndDate as timestamp) as IndexMemberWeightEndDate
,cast(IndexMemberWeightPercent as decimal(28, 12)) as IndexMemberWeightPercent
FROM 
IM_SZ_IMS_NS.ims_IndexBlendHierarchy_f1_v1_t2_current
