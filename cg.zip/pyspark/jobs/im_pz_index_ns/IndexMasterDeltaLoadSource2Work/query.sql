SELECT
cast(IndexUid as bigint) as IndexUid
,cast(IndexLongName as varchar(100)) as IndexLongName
,cast(IndexShortName as varchar(20)) as IndexShortName
,cast(IndexPrimaryVariantPortfolioUid as bigint) as IndexPrimaryVariantPortfolioUid
,cast(IndexPrimaryVariantName as varchar(200)) as IndexPrimaryVariantName
,cast(IndexPrimaryVariantReportingName as varchar(200)) as IndexPrimaryVariantReportingName
,cast(IndexBaseCurrencyUID as bigint) as IndexBaseCurrencyUID
,cast(IndexBaseCurrencyISOAlphaThreeCurrencyCode as varchar(3)) as IndexBaseCurrencyISOAlphaThreeCurrencyCode
,cast(IndexRebalanceFrequencyTypeName as varchar(50)) as IndexRebalanceFrequencyTypeName
,cast(IndexRebalanceTypeName as varchar(50)) as IndexRebalanceTypeName
,cast(IndexExchangeRateSourceName as varchar(100)) as IndexExchangeRateSourceName
,cast(IndexProviderIndustryClassificationSchemeName as varchar(100)) as IndexProviderIndustryClassificationSchemeName
,cast(IndexDividendReinvestmentScheduleName as varchar(100)) as IndexDividendReinvestmentScheduleName
,cast(IndexFirstQuoteDate as timestamp) as IndexFirstQuoteDate
,cast(IndexStartDate as timestamp) as IndexStartDate
,cast(IndexEndDate as timestamp) as IndexEndDate
,cast(IndexFamilyUid as bigint) as VendorUid
,cast(IndexFamilyName as varchar(100)) as VendorName
,cast(iva.VendorAbbreviationName as varchar(10)) as VendorAbbreviationName
,cast(IndexSourceSystemUid as bigint) as IndexSourceSystemUid
,cast(IndexSourceSystemName as varchar(50)) as IndexSourceSystemName
,cast(IndexTypeName as varchar(50)) as IndexTypeName
,cast((case when DeletionIndicator='True' then 'Y' when DeletionIndicator='False' then 'N' END) as varchar(1)) as DeletionIndicator
,cast((case when IndexExternalPublishIndicator='True' then 'Y'  when IndexExternalPublishIndicator='False' then  'N' END) as varchar(1)) as IndexExternalPublishIndicator
,cast(IndexToleranceValue as decimal(38, 8)) as IndexToleranceValue
,cast((case when IndexNoConstitentIndicator='True' then 'Y'  when IndexNoConstitentIndicator='False' then  'N' END) as varchar(1)) as IndexNoConstitentIndicator
,cast(IndexConstituentCount as bigint) as IndexConstituentCount
,cast(ReferenceDataProviderCode as varchar(10)) as ReferenceDataProviderCode
,cast(IndexEmergingMarketIndicator as varchar(1)) as IndexEmergingMarketIndicator
,cast(IndexHighYieldIndicator as varchar(1)) as IndexHighYieldIndicator
,cast(IndexAladdinTickerSymbol as varchar(25)) as IndexAladdinTickerSymbol
,cast(IndexAnalyticCalculationIndicator as varchar(1)) as IndexAnalyticCalculationIndicator
,cast((case when MultiIndexFamilyIndicator='True' then 'Y'  when MultiIndexFamilyIndicator='False' then  'N' END) as varchar(1)) as MultiIndexFamilyIndicator
FROM  
IM_SZ_IMS_NS.ims_Index_f1_v2_t2_current vw
LEFT JOIN (SELECT DISTINCT IMSVendorUID, VendorAbbreviationName
FROM IM_PZ_INDEX_NS.IMSVendorAbbreviation) iva 
ON vw.IndexFamilyUid=iva.IMSVendorUID
