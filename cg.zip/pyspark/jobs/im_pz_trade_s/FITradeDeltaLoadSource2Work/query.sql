SELECT
CAST(COALESCE(ppd.UniqueID,-999999999) as bigint) as UniqueID
,CAST(COALESCE(ppd.TradeID,-999999999) as bigint) as TradeID
,CAST(COALESCE(ppd.Version,-999) as int) as Version
,CAST(ppd.TradeExecutiondate as timestamp) as TradeExecutiondate
,CAST(ppd.Settlementdate as timestamp) as Settlementdate
,CAST(ppd.Maturitydate as timestamp) as Maturitydate
,CAST(ppd.TradeExecutionTimestamp as timestamp) as TradeExecutionTimestamp
,CAST(ppd.Createdate as timestamp) as Createdate
,CAST(ppd.TbaTradedate as timestamp) as TbaTradedate
,CAST(ppd.UpdateDate as timestamp) as UpdateDate
,CAST(ppd.Accrualdate as timestamp) as Accrualdate
,CAST(ppd.InterestPaymentdate as timestamp) as InterestPaymentdate
,CAST(ppd.RepoSettlementdate as timestamp) as RepoSettlementdate
,CAST(ppd.RollEnddate as timestamp) as RollEnddate
,CAST(ppd.AuthorizedTimestamp as timestamp) as AuthorizedTimestamp
,CAST(ppd.FactorAsOfdate as timestamp) as FactorAsOfdate
,CAST(ppd.ConfirmedTimestamp as timestamp) as ConfirmedTimestamp
,CAST(ppd.EffectiveTerminationdate as timestamp) as EffectiveTerminationdate
,CAST(ppd.Price as decimal(38, 8)) as Price
,CAST(ppd.DirtyPrice as decimal(38, 8)) as DirtyPrice
,CAST(ppd.VendorSettlementIsoCurrencyCode as varchar(3)) as VendorSettlementIsoCurrencyCode
,CAST(COALESCE(cur1.DWCurrencyID,-999999999) as bigint) as DWSettlementCurrencyID
,CAST(COALESCE(ppd.SettlementCurrencyUID,-999) as int) as SettlementCurrencyUID
,CAST(cur1.ISOAlphaThreeCurrencyCode as varchar(3)) as SettlementISOAlphaThreeCurrencyCode
,CAST(cur1.CurrencyName as varchar(50)) as SettlementCurrencyName
,CAST(ppd.VendorPayIsoCurrencyCode as varchar(3)) as VendorPayIsoCurrencyCode
,CAST(COALESCE(cur2.DWCurrencyID,-999999999) as bigint) as DWPayCurrencyID
,CAST(COALESCE(ppd.PayCurrencyUID,-999) as int) as PayCurrencyUID
,CAST(cur2.ISOAlphaThreeCurrencyCode as varchar(3)) as PayISOAlphaThreeCurrencyCode
,CAST(cur2.CurrencyName as varchar(50)) as PayCurrencyName
,CAST(ppd.VendorReceiveIsoCurrencyCode as varchar(3)) as VendorReceiveIsoCurrencyCode
,CAST(COALESCE(cur3.DWCurrencyID,-999999999) as bigint) as DWReceiveCurrencyID
,CAST(COALESCE(ppd.ReceiveCurrencyUID,-999) as int) as ReceiveCurrencyUID
,CAST(cur3.ISOAlphaThreeCurrencyCode as varchar(3)) as ReceiveISOAlphaThreeCurrencyCode
,CAST(cur3.CurrencyName as varchar(50)) as ReceiveCurrencyName
,CAST(ppd.FxTradePrice as decimal(38, 8)) as FxTradePrice
,CAST(ppd.FxSpotPrice as decimal(38, 8)) as FxSpotPrice
,CAST(ppd.RollPrice as decimal(38, 8)) as RollPrice
,CAST(ppd.DiscountPrice as decimal(38, 8)) as DiscountPrice
,CAST(ppd.ConfirmedBy as varchar(14)) as ConfirmedBy
,CAST(ppd.ConfirmedWith as varchar(14)) as ConfirmedWith
,CAST(ppd.CreatedBy as varchar(14)) as CreatedBy
,CAST(ppd.CreatedTimestamp as timestamp) as CreatedTimestamp
,CAST(ppd.ModifiedBy as varchar(14)) as ModifiedBy
,CAST(ppd.ModifiedTimestamp as timestamp) as ModifiedTimestamp
,CAST(COALESCE(ppd.VendorTradeVersionNumber,-999) as int) as VendorTradeVersionNumber
,CAST(ppd.TraderInitials as varchar(14)) as TraderInitials
,CAST(COALESCE(ppd.PlacementNumber,-999) as int) as PlacementNumber
,CAST(ppd.TransactionType as varchar(16)) as TransactionType
,CAST(ppd.TradeType as varchar(20)) as TradeType
,CAST(COALESCE(ppd.UniqueTransactionID,-999999999) as bigint) as UniqueTransactionID
,CAST(COALESCE(ppd.PreviousTransactionID,-999999999) as bigint) as PreviousTransactionID
,CAST(COALESCE(ppd.ReversalTransactionID,-999999999) as bigint) as ReversalTransactionID
,CAST(ppd.HasComplianceViolations as SMALLINT) as HasComplianceViolations
,CAST(ppd.ComplianceAcknowledgementStatus as varchar(25)) as ComplianceAcknowledgementStatus
,CAST(COALESCE(ppd.CounterpartyCode,-999) as int) as CounterpartyCode
,CAST(ppd.FwdCurrencyPrice as decimal(38, 8)) as FwdCurrencyPrice
,CAST(COALESCE(ppd.VendorTbaInvestmentNumber,-999) as int) as VendorTbaInvestmentNumber
,CAST(ppd.VendorCounterparty as varchar(20)) as VendorCounterparty
,CAST(ppd.VendorSecurityGroup as varchar(6)) as VendorSecurityGroup
,CAST(ppd.VendorSecurityTypeCode as varchar(10)) as VendorSecurityTypeCode
,CAST(ppd.VendorAccountingDesignationName as varchar(20)) as VendorAccountingDesignationName
,CAST(ppd.BrokerReasonCode as varchar(4)) as BrokerReasonCode
,CAST(ppd.CollateralExposureTypeCode as varchar(9)) as CollateralExposureTypeCode
,CAST(ppd.VendorInstrumentName as varchar(34)) as VendorInstrumentName
,CAST(COALESCE(ppd.VendorExecutingCounterpartyID,-999) as int) as VendorExecutingCounterpartyID
,CAST(ppd.VendorCounterpartyDeskIdentifier as varchar(1)) as VendorCounterpartyDeskIdentifier
,CAST(ppd.VendorCounterpartyDeskName as varchar(60)) as VendorCounterpartyDeskName
,CAST(ppd.CounterpartyDeskTypeCode as varchar(12)) as CounterpartyDeskTypeCode
,CAST(COALESCE(ppd.DaysToMaturityNumber,-999) as int) as DaysToMaturityNumber
,CAST(ppd.ExecutionTypeCode as varchar(1)) as ExecutionTypeCode
,CAST(ppd.ExecutionTimeSourceCode as varchar(1)) as ExecutionTimeSourceCode
,CAST(ppd.VendorExecutingBrokerDeskID as decimal(18, 2)) as VendorExecutingBrokerDeskID
,CAST(ppd.VendorExecutingBrokerDeskName as varchar(5)) as VendorExecutingBrokerDeskName
,CAST(ppd.FxSwapSettlementPayingLocationCode as varchar(10)) as FxSwapSettlementPayingLocationCode
,CAST(ppd.FxSwapSettlementReceivingLocationCode as varchar(10)) as FxSwapSettlementReceivingLocationCode
,CAST(ppd.FxSwapSecurityTypeCode as varchar(10)) as FxSwapSecurityTypeCode
,CAST(ppd.IsinIdentifier as varchar(20)) as IsinIdentifier
,CAST(ppd.NettingTransactionTypeCode as varchar(4)) as NettingTransactionTypeCode
,CAST(ppd.VendorMortgageSubtypeCode as varchar(9)) as VendorMortgageSubtypeCode
,CAST(ppd.NovationTypeCode as varchar(2)) as NovationTypeCode
,CAST(ppd.PrepaymentSpeedPercent as decimal(38, 8)) as PrepaymentSpeedPercent
,CAST(ppd.DebtPrepaymentTypeCode as varchar(3)) as DebtPrepaymentTypeCode
,CAST(ppd.RepoRatePercent as decimal(38, 8)) as RepoRatePercent
,CAST(ppd.RepoLendingRatePercent as decimal(38, 8)) as RepoLendingRatePercent
,CAST(ppd.RepoTransactionTypeCode as varchar(14)) as RepoTransactionTypeCode
,CAST(COALESCE(ppd.RollFrontEndInvestmentNumber,-999) as int) as RollFrontEndInvestmentNumber
,CAST(COALESCE(ppd.RollBackEndInvestmentNumber,-999) as int) as RollBackEndInvestmentNumber
,CAST(ppd.SedolIdentifier as varchar(20)) as SedolIdentifier
,CAST(ppd.SettlementExchangeRate as decimal(38, 8)) as SettlementExchangeRate
,CAST(COALESCE(ppd.VendorCouponFrequencyCode,-999) as int) as VendorCouponFrequencyCode
,CAST(COALESCE(ppd.VendorPrincipalFrequencyCode,-999) as int) as VendorPrincipalFrequencyCode
,CAST(ppd.VendorBrokerDeskID as decimal(18, 2)) as VendorBrokerDeskID
,CAST(ppd.TbaCusipID as varchar(9)) as TbaCusipID
,CAST(ppd.VendorTickerSymbol as varchar(16)) as VendorTickerSymbol
,CAST(ppd.VendorBrokerAkaName as varchar(60)) as VendorBrokerAkaName
,CAST(ppd.ConvexityPercent as decimal(38, 8)) as ConvexityPercent
,CAST(ppd.CouponRate as decimal(38, 8)) as CouponRate
,CAST(ppd.HaircutRate as decimal(38, 8)) as HaircutRate
,CAST(ppd.DurationPercent as decimal(38, 8)) as DurationPercent
,CAST(ppd.VendorExecutingBrokerName as varchar(20)) as VendorExecutingBrokerName
,CAST(ppd.VendorExecutingBrokerDeskTypeCode as varchar(12)) as VendorExecutingBrokerDeskTypeCode
,CAST(ppd.FinancingRate as decimal(38, 8)) as FinancingRate
,CAST(ppd.VendorTraderLocationName as varchar(10)) as VendorTraderLocationName
,CAST(ppd.PricingIndexName as varchar(9)) as PricingIndexName
,CAST(ppd.PricingSpreadPoints as decimal(38, 8)) as PricingSpreadPoints
,CAST(ppd.TradePurposeName as varchar(20)) as TradePurposeName
,CAST(ppd.VendorSettlementTemplateCode as varchar(255)) as VendorSettlementTemplateCode
,CAST(ppd.YieldPercent as decimal(38, 8)) as YieldPercent
,CAST(ppd.YieldToCallPercent as decimal(38, 8)) as YieldToCallPercent
,CAST(ppd.FaceAmountQuantityTypeCode as varchar(10)) as FaceAmountQuantityTypeCode
,CAST(COALESCE(ppd.OriginalInvestmentNumber,-999) as int) as OriginalInvestmentNumber
,CAST(ppd.VendorSecurityMasterIsoCurrencyCode as varchar(3)) as VendorSecurityMasterIsoCurrencyCode
,CAST(COALESCE(ppd.SecurityMasterCurrencyUID,-999) as int) as SecurityMasterCurrencyUID
,CAST(ppd.VendorAssetID as varchar(9)) as VendorAssetID
,CAST(COALESCE(ppd.ListingUID,-999999999) as bigint) as ListingUID
,CAST(COALESCE(list.DWListingID,-999999999) as bigint) as DWListingID
,CAST(COALESCE(ppd.ExecutingBrokerID,-999) as int) as ExecutingBrokerID
,CAST(COALESCE(bkg1.DWBrokerid,-999999999) as bigint) as DWExecutingBrokerID
,CAST(COALESCE(ppd.VendorExecutingBrokerID,-999) as int) as VendorExecutingBrokerID
,CAST(COALESCE(ppd.CounterpartyAAPortfolioUID,-999) as int) as CounterpartyAAPortfolioUID
,CAST(COALESCE(cgport.DWCGPortfolioID,-999999999) as bigint) as DWCounterpartyAAPortfolioID
,CAST(ppd.Factor as decimal(18, 8)) as Factor
,CAST(ppd.Status as varchar(1)) as Status
,CAST(ppd.TradeFlags as varchar(14)) as TradeFlags
,CAST(ppd.IsFreeDelivery as int) as IsFreeDelivery
,CAST(ppd.CurrentStateName as varchar(20)) as CurrentStateName
,CAST(ppd.ComplianceAcknowledgementMessage as varchar(2048)) as ComplianceAcknowledgementMessage
,CAST(ppd.SpotVendorAssetID as varchar(9)) as SpotVendorAssetID
,CAST(ppd.PublicationStatus as varchar(9)) as PublicationStatus
,CAST(CASE WHEN fta.ManagerInitials = 'ROUND ROBIN' THEN 'Y' ELSE 'N' END as varchar(1)) as RoundRobinTradeInd
FROM
IM_SZ_FLCNADPTR_S.flcn_aldn_trade_f1_v1_t1_CURRENT ppd
LEFT OUTER JOIN (select a.TradeID, a.ManagerInitials
from im_pz_trade_s.FITradeAllocation a,
    (select TradeID, max(UniqueID) UniqueID
      from im_pz_trade_s.FITradeAllocation
	   where InvestmentPortfolioTypeCode = 'AM'
	  group by TradeID) t
where a.TradeID = t.TradeID
and a.UniqueID = t.UniqueID) fta
	   ON ppd.TradeID = fta.TradeID
LEFT OUTER JOIN im_pz_sharedrefdata_ns.currency cur1
	   ON (ppd.SettlementCurrencyUID = cur1.CurrencyUID and to_date(ppd.TradeExecutionDate) between to_date(cur1.DWEffectiveFromDate) AND  to_date(cur1.DWEffectiveToDate))
LEFT OUTER JOIN im_pz_sharedrefdata_ns.currency cur2
	   ON (ppd.PayCurrencyUID = cur2.CurrencyUID and to_date(ppd.TradeExecutionDate) between to_date(cur2.DWEffectiveFromDate) AND  to_date(cur2.DWEffectiveToDate))
LEFT OUTER JOIN im_pz_sharedrefdata_ns.currency cur3
	   ON (ppd.ReceiveCurrencyUID = cur2.CurrencyUID and to_date(ppd.TradeExecutionDate) between to_date(cur3.DWEffectiveFromDate) AND  to_date(cur3.DWEffectiveToDate))
LEFT OUTER JOIN im_pz_sharedrefdata_ns.listing list
       ON (ppd.ListingUID = list.ListingUID and to_date(ppd.TradeExecutionDate) between to_date(list.DWEffectiveFromDate) AND  to_date(list.DWEffectiveToDate))
LEFT OUTER JOIN im_pz_trade_s.brokerage bkg1
	   ON (ppd.ExecutingBrokerID = bkg1.BrokerUID and to_date(ppd.TradeExecutionDate) between to_date(bkg1.DWEffectiveFromDate) AND  to_date(bkg1.DWEffectiveToDate))
LEFT OUTER JOIN im_pz_portfoliopos_s.cgportfolio cgport
	   ON (ppd.CounterpartyAAPortfolioUID = cgport.PortfolioUID and to_date(ppd.TradeExecutionDate) between to_date(cgport.DWEffectiveFromDate) AND  to_date(cgport.DWEffectiveToDate))