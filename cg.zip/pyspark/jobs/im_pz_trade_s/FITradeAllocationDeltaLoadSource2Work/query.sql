SELECT /*+ broadcast(bkg1, bkg2, ppd) */ 
CAST(COALESCE(ppd.UniqueID,-999999999) as bigint) as UniqueID,
CAST(COALESCE(ppd.TradeAllocationID,-999999999) as bigint) as TradeAllocationID,
CAST(COALESCE(ppd.Version,-999) as int) as Version,
CAST(COALESCE(ppd.TradeID,-999999999) as bigint) as TradeID,
CAST(COALESCE(ppd.TradeVersion,-999) as int) as TradeVersion,
CAST(COALESCE(ppd.UniqueTransactionID,-999999999) as bigint) as UniqueTransactionID,
CAST(COALESCE(ppd.PreviousTransactionID,-999999999) as bigint) as PreviousTransactionID,
CAST(COALESCE(ppd.ReversalTransactionID,-999999999) as bigint) as ReversalTransactionID,
CAST(COALESCE(cgport.DWCGPortfolioID,-999999999) as bigint) as DWCGPortfolioID,
CAST(COALESCE(ppd.PortfolioUID,-999) as int) as PortfolioUID,
CAST(cgport.InvestmentPortfolioTypeCode as varchar(10)) as InvestmentPortfolioTypeCode,
CAST(COALESCE(ppd.RollupTradeAllocationID,-999999999) as bigint) as RollupTradeAllocationID,
CAST(COALESCE(ppd.VendorPortfolioUID,-999) as int) as VendorPortfolioUID,
CAST(COALESCE(ppd.VendorStrategyUID,-999) as int) as VendorStrategyUID,
CAST(COALESCE(ppd.VendorInvestmentNumber,-999) as int) as VendorInvestmentNumber,
CAST(COALESCE(ppd.VendorMbsAllocationNumber,-999) as int) as VendorMbsAllocationNumber,
CAST(COALESCE(ppd.VendorInterPortfolioID,-999) as int) as VendorInterPortfolioID,
CAST(COALESCE(ppd.VendorInterPortfolioInvestmentNumber,-999) as int) as VendorInterPortfolioInvestmentNumber,
CAST(COALESCE(ppd.VendorTouchCount,-999) as int) as VendorTouchCount,
CAST(ppd.CurrentFaceAmount as decimal(38, 8)) as CurrentFaceAmount,
CAST(ppd.OriginalFaceAmount as decimal(38, 8)) as OriginalFaceAmount,
CAST(ppd.CommissionAmount as decimal(38, 8)) as CommissionAmount,
CAST(ppd.OtherFeesAmount as decimal(38, 8)) as OtherFeesAmount,
CAST(ppd.PrincipalAmount as decimal(38, 8)) as PrincipalAmount,
CAST(ppd.InterestAmount as decimal(38, 8)) as InterestAmount,
CAST(ppd.PayCurrencyAmount as decimal(38, 8)) as PayCurrencyAmount,
CAST(ppd.ReceiveCurrencyAmount as decimal(38, 8)) as ReceiveCurrencyAmount,
CAST(ppd.NetMoneyAmount as decimal(38, 8)) as NetMoneyAmount,
CAST(COALESCE(ppd.ClearingBrokerID,-999) as int) as ClearingBrokerID,
CAST(COALESCE(bkg1.DWBrokerid,-999999999) as bigint) as DWClearingBrokerID, 
CAST(COALESCE(ppd.VendorClearingBrokerID,-999) as int) as VendorClearingBrokerID,
CAST(COALESCE(bkg2.DWBrokerid,-999999999) as bigint) as DWVendorClearingBrokerID,
CAST(ppd.VendorPortfolioName as varchar(10)) as VendorPortfolioName,
CAST(ppd.FwdBuyCurrencyAmount as decimal(38, 8)) as FwdBuyCurrencyAmount,
CAST(ppd.FwdSellCurrencyAmount as decimal(38, 8)) as FwdSellCurrencyAmount,
CAST(ppd.BaseSettlementExchangeRate as decimal(38, 8)) as BaseSettlementExchangeRate,
CAST(ppd.HaircutAmount as decimal(38, 8)) as HaircutAmount,
CAST(ppd.InterestAtMaturityAmount as decimal(38, 8)) as InterestAtMaturityAmount,
CAST(ppd.RollFeeAmount as decimal(38, 8)) as RollFeeAmount,
CAST(ppd.RollInterestAmount as decimal(38, 8)) as RollInterestAmount,
CAST(ppd.RollPrincipalAmount as decimal(38, 8)) as RollPrincipalAmount,
CAST(ppd.ExCommissionAmount as decimal(38, 8)) as ExCommissionAmount,
CAST(ppd.TbaAllowedVarianceAmount as decimal(38, 8)) as TbaAllowedVarianceAmount,
CAST(ppd.ExternalAccountID as varchar(60)) as ExternalAccountID,
CAST(ppd.TradeFifoTypeCode as varchar(6)) as TradeFifoTypeCode,
CAST(ppd.ManagerInitials as varchar(14)) as ManagerInitials,
CAST(ppd.CustodianAccountID as varchar(60)) as CustodianAccountID,
CAST(ppd.CustodianAccountLocationCode as varchar(10)) as CustodianAccountLocationCode,
CAST(ppd.CfdFlag as varchar(2)) as CfdFlag,
CAST(ppd.VendorPaySettlementLocationCode as varchar(10)) as VendorPaySettlementLocationCode,
CAST(ppd.VendorReceiveSettlementLocationCode as varchar(10)) as VendorReceiveSettlementLocationCode,
CAST(ppd.VendorSettlementLocationCode as varchar(10)) as VendorSettlementLocationCode,
CAST(COALESCE(ppd.VendorTradeNumber,-999) as int) as  VendorTradeNumber,
CAST(ppd.SwapTransactionTypeCode as varchar(60)) as SwapTransactionTypeCode
FROM im_sz_flcnadptr_s.flcn_aldn_trade_alloc_f1_v1_t1_current ppd
inner join 
    (SELECT CycleDate FROM im_pz_trade_s.AppCycleDate WHERE ltrim(rtrim(CycleCode)) = 'im-trade') cd on 1=1
LEFT OUTER JOIN 
    (select
PortfolioUID
,DWEffectiveFromDate
,DWEffectiveToDate
,DWCGPortfolioID
,InvestmentPortfolioTypeCode
from im_pz_portfoliopos_s.cgportfolio
) cgport ON ppd.PortfolioUID = cgport.PortfolioUID  
LEFT OUTER JOIN im_pz_trade_s.brokerage bkg1
ON (ppd.ClearingBrokerID = bkg1.BrokerUID and to_date(cd.CycleDate) between to_date(bkg1.DWEffectiveFromDate) and to_date(bkg1.DWEffectiveToDate))
LEFT OUTER JOIN im_pz_trade_s.brokerage bkg2
ON (ppd.VendorClearingBrokerID = bkg2.BrokerUID and to_date(cd.CycleDate) between to_date(bkg2.DWEffectiveFromDate) and to_date(bkg2.DWEffectiveToDate))
where
to_date(cd.CycleDate) between to_date(cgport.DWEffectiveFromDate) and to_date(cgport.DWEffectiveToDate)

