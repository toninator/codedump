SELECT
    CAST(COALESCE(BrokerUniqueIdentifier,-999) as int) as BrokerUID
    ,CAST(COALESCE(BusinessPartnerUniqueIdentifier,-999) as int) as BusinessPartnerUID
    ,TRIM(CAST(BusinessName as VARCHAR(60))) as BusinessName
    ,CAST(COALESCE(BrokerNumber,-999) as int) as BrokerNumber
    ,CAST(COALESCE(BrokerSequenceNumber,-999) as int) as BrokerSequenceNumber
    ,TRIM(CAST(BrokerShortName as VARCHAR(15))) as BrokerShortName
    ,CAST(COALESCE(NewBrokerUniqueIdentifier,-999) as int) as NewBrokerUID
    ,CAST(COALESCE(CountryUniqueIdentifier,-999) as int) as CountryUID
    ,TRIM(CAST(BrokerLongName as VARCHAR(60))) as BrokerLongName
    ,CAST(COALESCE(DTCNumber,-999) as int) as DTCNumber
    ,TRIM(CAST(BrokerageTaxNumber as VARCHAR(10))) as BrokerageTaxNumber
    ,TRIM(CAST(GeneralComments as VARCHAR(80))) as GeneralComments
    ,TRIM(CAST(CityName as VARCHAR(20))) as CityName
    ,TRIM(CAST(CGBrokerCode as VARCHAR(5))) as CGBrokerCode
    ,TRIM(CAST(OasysBrokerCode as VARCHAR(8))) as OasysBrokerCode
    ,TRIM(CAST(OasysBocCode as VARCHAR(30))) as OasysBocCode
    ,TRIM(CAST(ActiveFlag as char(1))) as ActiveFlag
    ,TRIM(CAST(ExecutionBrokerBICCode as VARCHAR(15))) as ExecutionBrokerBICCode
    ,TRIM(CAST(ClearingBrokerName as VARCHAR(30))) as ClearingBrokerName
    ,TRIM(CAST(BrokerageClassCode as VARCHAR(5))) as BrokerageClassCode
    ,TRIM(CAST(SpiiBrokerTypeCode as VARCHAR(2))) as SpiiBrokerTypeCode
    ,TRIM(CAST(OasysGlobalBrokerCode as VARCHAR(8))) as OasysGlobalBrokerCode
    ,TRIM(CAST(LegalEntityIdentifier as VARCHAR(20))) as LegalEntityIdentifier
    ,TRIM(CAST(ABANumber as VARCHAR(9))) as ABANumber
    ,TRIM(CAST(ExecutionBrokerFINSNumber as VARCHAR(7))) as ExecutionBrokerFINSNumber
    ,TRIM(CAST(LastModifiedInitials as VARCHAR(8))) as LastModifiedInitials
    ,CAST(LastModifiedTimestamp as TIMESTAMP) as LastModifiedTimestamp
    ,TRIM(CAST(LegalEntityDescription as VARCHAR(32))) as LegalEntityDescription
    ,CAST(COALESCE(ExternalBrokerUniqueIdentifier,-999) as int) as ExternalBrokerUID
    ,CAST(COALESCE(ExternalBrokerDeskUniqueIdentifier,-999) as int) as ExternalBrokerDeskUID
    ,TRIM(CAST(ExternalBrokerIssuerCode as VARCHAR(6))) as ExternalBrokerIssuerCode
FROM
    im_sz_bcs_s.bcs_brokerage_f2_v1_t1_current
