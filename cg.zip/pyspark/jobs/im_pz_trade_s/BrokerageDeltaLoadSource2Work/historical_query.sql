SELECT * FROM parquet.`adl://lasradl1oz.azuredatalakestore.net/lasr/data/historical/IM_PZ_TRADE_S/Brokerage`
