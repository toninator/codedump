with cdate_qry as (
SELECT cycledate FROM im_pz_sharedrefdata_ns.appcycledate WHERE trim(lower(cyclecode)) = 'im-daily'
)
SELECT /*+ broadcast (cdate_qry) */
COALESCE(CAST(cgp.PortfolioUID AS bigint),-9999999999) AS PortfolioUID,
COALESCE(CAST(cgp.InvestmentPortfolioTypeCode AS VARCHAR(10)),'Unknown') AS InvestmentPortfolioTypeCode, 
COALESCE(CAST(cgp.PortfolioName AS VARCHAR(100)),'Unknown') AS PortfolioName, 
COALESCE(CAST(list.listingUid AS bigint), -9999999999) AS listingUid,  
CAST(list.ListingCGSymbol AS VARCHAR(10)) AS ListingCGSymbol,  
CAST(list.ListingLongName AS VARCHAR(100)) AS ListingLongName                            
FROM im_pz_portfoliopos_s.CGPortfolioProperty cgpp
    INNER JOIN cdate_qry 
    ON 1=1
    -- WHERE to_date(cycledate) between to_date(dweffectivefromdate) and to_date(dweffectivetodate)
    INNER JOIN (
        SELECT cgpf.PortfolioUID, cgpf.InvestmentPortfolioTypeCode, cgpf.PortfolioName, cgpf.InvestmentAccountUID, cgpf.dweffectivefromdate, cgpf.dweffectivetodate
        FROM IM_PZ_PORTFOLIOPOS_S.CGPortfolio cgpf
    ) cgp
    ON cgpp.PortfolioUID = cgp.PortfolioUID
    INNER JOIN (
      SELECT lst.listinguid, lst.listingcgsymbol, lst.listinglongname, lst.dweffectivetodate, lst.dweffectivefromdate 
        FROM IM_PZ_SHAREDREFDATA_NS.Listing lst
    ) list
    ON list.ListingUID = CAST(cgpp.PropertyValue AS bigint) 
    WHERE to_date(cycledate) BETWEEN  to_date(cgp.DWEffectiveFromDate) and to_date(cgp.DWEffectiveToDate)
    AND to_date(cycledate) BETWEEN  to_date(list.DWEffectiveFromDate) and to_date(list.DWEffectiveToDate)
    AND LOWER(cgpp.PropertyDefinitionName) = 'umplistinguid'
UNION ALL
SELECT /*+ broadcast (cdate_qry) */ DISTINCT 
CAST(cgpf.PortfolioUID AS BIGINT) AS PortfolioUID
        , CAST(TRIM(cgpf.InvestmentPortfolioTypeCode) AS VARCHAR(10)) AS InvestmentPortfolioTypeCode
        , CAST(TRIM(cgpf.PortfolioName) AS VARCHAR(100)) AS PortfolioName
        , CAST(fsc.listingUid AS BIGINT) AS ListingUID
        , CAST(TRIM(lst.ListingCGSymbol) AS VARCHAR(10)) AS ListingCGSymbol
        , CAST(TRIM(lst.ListingLongName) AS VARCHAR(100)) AS ListingLongName
FROM IM_PZ_ACCTPOSTRANS_S.FundShareClass fsc
    INNER JOIN cdate_qry 
    ON 1=1
    INNER JOIN (
        SELECT lst.listinguid, lst.listingcgsymbol, lst.listinglongname, lst.dweffectivetodate, lst.dweffectivefromdate 
        FROM IM_PZ_SHAREDREFDATA_NS.Listing lst
        -- WHERE '2020-03-12 00:00:00' BETWEEN lst.DWeffectiveFromDate AND lst.DWEffectiveToDate
        ) lst
    ON (fsc.listinguid=lst.listinguid)
    INNER JOIN (
        SELECT cgpf.PortfolioUID, cgpf.InvestmentPortfolioTypeCode, cgpf.PortfolioName, cgpf.InvestmentAccountUID, cgpf.dweffectivefromdate, cgpf.dweffectivetodate
        FROM IM_PZ_PORTFOLIOPOS_S.CGPortfolio cgpf 
        -- WHERE '2020-03-12 00:00:00' BETWEEN cgpf.DWeffectiveFromDate AND cgpf.DWEffectiveToDate
        -- AND cgpf.InvestmentPortfolioTypeCode='AA'
        ) cgpf
    ON (fsc.InvestmentAccountUID = cgpf.InvestmentAccountUID)
    WHERE lst.listingUid not in (-9999999999,213106480)
    AND to_date(cycledate) BETWEEN to_date(cgpf.DWeffectiveFromDate) AND to_date(cgpf.DWEffectiveToDate)
    AND cgpf.InvestmentPortfolioTypeCode='AA'
    AND to_date(cycledate) BETWEEN to_date(lst.DWeffectiveFromDate) AND to_date(lst.DWEffectiveToDate)
    AND to_date(cycledate) BETWEEN to_date(fsc.DWeffectiveFromDate) AND to_date(fsc.DWEffectiveToDate)
UNION ALL
SELECT /*+ broadcast (cdate_qry) */ DISTINCT
        CAST(cgpf.PortfolioUID AS BIGINT) AS PortfolioUID
        , CAST(TRIM(cgpf.InvestmentPortfolioTypeCode) AS VARCHAR(10)) AS InvestmentPortfolioTypeCode
        , CAST(TRIM(cgpf.PortfolioName) AS VARCHAR(100)) AS PortfolioName
        , CAST(lst.listingUid AS BIGINT) AS ListingUID
        , CAST(TRIM(lst.ListingCGSymbol) AS VARCHAR(10)) AS ListingCGSymbol
        , CAST(TRIM(lst.ListingLongName) AS VARCHAR(100)) AS ListingLongName
    FROM IM_SZ_FDW_NS.isg_fdw_fund_asset_ref_full_f1_v1_t1_CURRENT port
    INNER JOIN cdate_qry 
    ON 1=1
    INNER JOIN (
        SELECT inst.InstrumentIsinID, inst.dwinstrumentid, inst.dweffectivefromdate, inst.dweffectivetodate
        FROM IM_PZ_SHAREDREFDATA_NS.Instrument inst
    ) inst
    ON (port.ISIN=inst.InstrumentIsinID 
    AND port.ISIN IS NOT NULL)
    INNER JOIN (
      SELECT lst.listinguid, lst.listingcgsymbol, lst.listinglongname, lst.dwinstrumentid, lst.dweffectivetodate, lst.dweffectivefromdate 
        FROM IM_PZ_SHAREDREFDATA_NS.Listing lst
    ) lst
    ON (inst.DWInstrumentID=lst.DWInstrumentID)
    INNER JOIN IM_PZ_ACCTPOSTRANS_S.InvestmentAccount inac
    ON (port.PORT_ACCOUNTING_ACCOUNT_ID=inac.InvestmentAccountNumber)
    INNER JOIN (
        SELECT cgpf.PortfolioUID, cgpf.InvestmentPortfolioTypeCode, cgpf.PortfolioName, cgpf.dweffectivefromdate, cgpf.dweffectivetodate
        FROM IM_PZ_PORTFOLIOPOS_S.CGPortfolio cgpf
    ) cgpf
    ON (inac.PortfolioUID=cgpf.PortfolioUID)
    WHERE lst.listingUid not in (-9999999999,213106480)
    AND to_date(cycledate) BETWEEN to_date(inst.DWeffectiveFromDate) AND to_date(inst.DWEffectiveToDate) 
    AND to_date(cycledate) BETWEEN to_date(lst.DWeffectiveFromDate) AND to_date(lst.DWEffectiveToDate)
    AND to_date(cycledate) BETWEEN to_date(cgpf.DWeffectiveFromDate) AND to_date(cgpf.DWEffectiveToDate)
    AND to_date(cycledate) BETWEEN to_date(inac.DWeffectiveFromDate) AND to_date(inac.DWEffectiveToDate)
