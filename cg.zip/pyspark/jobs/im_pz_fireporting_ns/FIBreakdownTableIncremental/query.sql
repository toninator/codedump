SELECT distinct a.Listing_UID , a.BREAKDOWN_TAG,a.SECTOR_TITLE,a.rundate__  FileTimeStamp
FROM im_sz_flcnadptr_s.flcn_aldn_sec_class_f1_v1_t1_current a
LEFT OUTER JOIN (SELECT * FROM im_sz_flcnadptr_s.flcn_aldn_sec_class_f1_v1_t1 where rundate__='{0}') b
ON (a.Listing_UID = b.Listing_UID AND a.BREAKDOWN_TAG = b.BREAKDOWN_TAG AND a.SECTOR_TITLE = b.SECTOR_TITLE)
WHERE b.Listing_UID IS NULL