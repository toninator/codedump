"""
FIBreakdownTableIncremental
"""

import cgcommon.cgspark as cg
import cgcommon.dataframe as df
from cgcommon.params import Conf

import datetime
from pyspark.sql import Row
from pyspark.sql.functions import col,split,lit


def main():

	# delimited list argument passed
	file_list = cg.get_filenames()

	# get spark session, logger, and config dict
	spark, log, config = cg.start_spark(
		app_name='FIBreakdownTableIncremental'
		, files=file_list
		, spark_conf={"spark.sql.session.timeZone": "UTC"
			, "spark.sql.sources.partitionOverwriteMode": "dynamic"
			, "spark.sql.hive.convertMetastoreParquet": "false"
			, "hive.exec.dynamic.partition": "true"
			, "hive.exec.dynamic.partition.mode": "nonstrict"
			, "spark.sql.shuffle.partitions": 64})
	
	print("Spark Confs: " + str(spark.sparkContext.getConf().getAll()))
	
	# set parameters with conf dictionary
	p = Conf(config)

	log.warn("FIBreakdownTableIncremental ,ParsedBreakDownWork  starting")
	
	source_df = extract(spark, log, p)
	transformAndLoad(spark, source_df, p, log)
	
	log.warn("FIBreakdownTableIncremental , ParsedBreakDownWork finished")
	spark.stop()
	
	return None

def extract(spark, log, p):
	"""Read data from hive or parquet"""
	

	# read extract sql query string from config
	query = cg.get_query(log, p.query_file)

	currentFileTimeStamp=spark.sql("SELECT max(rundate__) FROM im_sz_flcnadptr_s.flcn_aldn_sec_class_f1_v1_t1_current").collect()[0]['max(rundate__)']
	prevFileTimeStamp=spark.sql("SELECT max(rundate__) FROM im_sz_flcnadptr_s.flcn_aldn_sec_class_f1_v1_t1  where rundate__<>'{0}'".format(currentFileTimeStamp)).collect()[0]['max(rundate__)']
	
	log.info("currentFileTimeStamp={0}".format(currentFileTimeStamp))
	log.info("prevFileTimeStamp={0}".format(prevFileTimeStamp))
	log.info("queryNewBreakdownChanges={0}".format(query.format(prevFileTimeStamp)))

	work = spark.sql(query.format(prevFileTimeStamp))
	
	ParsedBreakDownWork=work.withColumn("BreakdownLevel1",split(col("sector_title"),"[|]").getItem(1))\
	.withColumn("BreakdownLevel2",split(col("sector_title"),"[|]").getItem(2))\
	.withColumn("BreakdownLevel3",split(col("sector_title"),"[|]").getItem(3))\
	.withColumn("BreakdownLevel4",split(col("sector_title"),"[|]").getItem(4))\
	.withColumn("BreakdownLevel5",split(col("sector_title"),"[|]").getItem(5))\
	.withColumn("BreakdownLevel6",split(col("sector_title"),"[|]").getItem(6))\
	.withColumn("BreakdownLevel7",split(col("sector_title"),"[|]").getItem(7))\
	.withColumn("BreakdownLevel8",split(col("sector_title"),"[|]").getItem(8))\
	.withColumn("BreakdownLevel9",split(col("sector_title"),"[|]").getItem(9))
	
	return ParsedBreakDownWork
	
	
def transformAndLoad(spark, dfs, p, log):
	"""Loads dataframe to table"""

	
	dfs.registerTempTable("ParsedBreakDownWork")
	
	# Removing ListingUid & getting distinct categorization to reduce dataset
	FIBreakdownTableIncremental=spark.sql("""SELECT distinct breakdown_tag,sector_title,FileTimeStamp
											BreakdownLevel1,BreakdownLevel2,BreakdownLevel3,BreakdownLevel4,
											BreakdownLevel5,BreakdownLevel6,BreakdownLevel7,BreakdownLevel8,BreakdownLevel9 
											FROM ParsedBreakDownWork""")

	df.insert_into(spark, FIBreakdownTableIncremental, log, p.database, p.table, p.parent_path
				, part_column=p.part_col
				, part_reference=p.partition_reference
				, part_number=2
				, part_column_type=p.partition_type)
											
											
	# # Create/Load  FIBreakdownTableIncremental table schema
	# cg.create_external(spark, FIBreakdownTableIncremental, log, p.database, p.table, p.target_path
						# , part_column=p.part_col
						# , part_reference=p.partition_reference
						# , part_number=2
						# , part_column_type=p.partition_type)
						
	# load_df = df.add_partition_column(FIBreakdownTableIncremental, p.part_col,p.partition_reference,p.partition_type)
	# df.insert_into(spark,load_df,log, p.database, p.table,p.parent_path)
	# Create/Load  ParsedBreakDownWork table schema
	target_table="ParsedBreakDownWork"
	target_path=f"{p.parent_path}/{p.database}/{target_table}/"
	df.insert_into(spark, dfs, log, p.database, target_table, target_path
			, part_column=p.part_col
			, part_reference=p.partition_reference
			, part_number=2
			, part_column_type=p.partition_type)
			
	# cg.create_external(spark, dfs, log, p.database, target_table, target_path
					# , part_column=p.part_col
					# , part_reference=p.partition_reference
					# , part_number=2
					# , part_column_type=p.partition_type)

	# load_df1 = df.add_partition_column(dfs, p.part_col,p.partition_reference,p.partition_type)
	# df.insert_into(load_df1, p.database, target_table)
	
	return None
	



# entry point for PySpark ETL application
if __name__ == '__main__':
	main()