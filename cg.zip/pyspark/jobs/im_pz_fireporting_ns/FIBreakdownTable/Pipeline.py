"""
FIBreakdownTables 
"""

import datetime
from pyspark.sql.functions import col,split,lit
from pyspark.sql.types import *

import cgcommon.cgspark as cg
import cgcommon.dataframe as df
from cgcommon.params import Conf



def main():

	# delimited list argument passed
	file_list = cg.get_filenames()
	# get spark session, logger, and config dict
	spark, log, config = cg.start_spark(
		app_name='FIBreakdownTables'
		, files=file_list
		, spark_conf={"spark.sql.session.timeZone": "UTC"
			, "spark.sql.sources.partitionOverwriteMode": "dynamic"
			, "spark.sql.hive.convertMetastoreParquet": "false"
			, "hive.exec.dynamic.partition": "true" 
			, "hive.exec.dynamic.partition.mode": "nonstrict"
			, "spark.sql.shuffle.partitions": 64})
	
	# set parameters with conf dictionary
	p = Conf(config)
	
	# Initiate process of Extract / transfom / Load of FI Breakdown tables
	FIBreakdownTableIncremental , BreakdownList = extract(spark, log, p)
	transformAndLoad(FIBreakdownTableIncremental,BreakdownList,spark, log, config)
	
	spark.stop()
	return None

def extract(spark, log, p):
	"""Read data from hive or parquet"""
	
	appcycledate = spark.sql(f"""
	select cast(cycledate as string) as cd 
	from {p.database}.appcycledate 
	where cyclecode = '{p.cyclecode}'
	""").collect()[0]['cd'][:19]
	log.info("cycledate = " + appcycledate)	
	
	# Load data from incremental table of categorization - FIBreakdownTableIncremental
	FIBreakdownTableIncremental=spark.sql("SELECT * FROM im_pz_fireporting_ns.fibreakdowntableincremental")

	# Load control data for iteration over above table 
	BreakdownList = spark.sql("SELECT * FROM im_pz_fireporting_ns.breakdownlist where generatetableind='Y'")
	BreakdownList = BreakdownList.coalesce(1).persist().collect()
	return FIBreakdownTableIncremental , BreakdownList
	


def transformAndLoad(df_extract,df_iterator ,spark,log,config):
	"""Transform FIBreakdownTableIncremental by parsing sector_title into BreakDown Columns"""

	for r in df_iterator:#.take(2):#collect():#:
		source_dw_df=df_extract.filter(df_extract["p_col"].isin(r.breakdownname)).select([c for c in df_extract.columns if c in ["BreakdownLevel"+str(a+1) for a in range(r.maxbreakdownlevel)]])

		# set parameters with conf dictionary
		print("start config load")
		config['dw_key']= "dw{}id".format(r.mappedtablename)
		config['table']=r.mappedtablename
		config['work_table']=r.mappedtablename+"_work"
		config['join_keys']=["BreakdownLevel"+str(a+1) for a in range(r.maxbreakdownlevel)]
		config['database']=config['database'].upper()
		
		if (r.breakdownname=="CG_BARCLAYS"):
			source_dw_df=source_dw_df.withColumn("IsCustom", lit("Y"))
			config['join_keys']=["BreakdownLevel"+str(a+1) for a in range(r.maxbreakdownlevel)] + ["IsCustom"]
		print("Create param object")
		p = Conf(config)
		
		try:
			print("Start load method")
			load(spark, source_dw_df, p, log)
		except Exception as e:
			log.error(f"Failed to load  table {p.table}")
			log.error(str(e))
			print(str(e))
	
	#Cleanup the memory
	# df_iterator.unpersist()
	return None
	
def load(spark, source_df, p, log):
	"""Loads dataframe to table"""

	print("Loading Table : {0}",p.table)
	# print config dictionary
	print(vars(p))
	
	# add dw columns to source dataframe
	source_dw_df = df.add_dw_columns(source_df, p)
	
	# prepare final dataframe with new records using SCD1 function
	target_df = spark.sql(f"select * from {p.database}.{p.table}")
	# target_df = df.extract_compare_set(spark, p.database,p.table)

	print ("CDC start ")
	cdc_df = df.change_data_capture(spark,source_dw_df, target_df, p, log)
	# log.info("Table : Modified Records Count : {0}".format(cdc_df.count()))
	
	print ("INSERT Into start ")
	df.insert_into(spark,cdc_df,log, p.database, p.table,p.parent_path)
	print ("Complete insert Into start ")

	return None



# entry point for PySpark ETL application
if __name__ == '__main__':
	main()