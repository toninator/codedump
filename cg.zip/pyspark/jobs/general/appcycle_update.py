"""
appcycle_update.py
~~~~~~~~~~~~~~~~~~
Common process to update appcycle dates per database per processid

"""
import sys

import cgcommon.cgspark as cg
import cgcommon.dataframe as df
from cgcommon.params import Conf


def load(spark, p, log):
    """function to load appcycledate records per database per cyclecode"""
    cd_query = """select 
substr(cast(nextglobalbusinessdate as string),1,10) as cd 
from im_pz_sharedrefdata_ns.CGCalendar 
where substr(cast(calendardate as string),1,10)  = cast( date_add(current_date,-1) as string)
"""
    where_condition = spark.sql(cd_query).collect()[0]['cd']

    if cg.table_check(spark, p.database, p.table):
        cd_query_from_table = f"""select 
substr(cast(nextglobalbusinessdate as string),1,10) as cd
from {p.database}.{p.table} where cyclecode  = '{p.cyclecode}'
"""
        cycledate_from_table = spark.sql(cd_query_from_table)
        if len(cycledate_from_table.head(1)) == 0:
            print(f"No record for {p.cyclecode}")
        else:
            where_condition = cycledate_from_table.collect()[0]['cd']

    query = f"""
select 
cast({p.appid} as bigint) as appid
,'{p.cyclecode}' as cyclecode
,'{p.appname}' as appname
,calendardate as cycledate
,priorusbusinessdate
,nextusbusinessdate
,priorglobalbusinessdate
,nextglobalbusinessdate
,monthenddate
from im_pz_sharedrefdata_ns.CGCalendar 
where substr(cast(calendardate as string),1,10) = '{where_condition}'
"""
    print(query)
    appcycledate_df = spark.sql(query)
    # load_df = df.add_partition_column(appcycledate_df, p)
    df.insert_into(spark, appcycledate_df, log, p.database, p.table, p.parent_path, part_number=1, part_column=p.part_col, part_reference=p.partition_reference)

    return None


def main(pipeline):
    file_list = cg.get_filenames()

    # get spark session, logger, and config dict
    spark, log, config = cg.start_spark(
        app_name='appcycledate'
        , files=file_list
        , spark_conf={"spark.sql.session.timeZone": "UTC"
            , "spark.sql.sources.partitionOverwriteMode": "dynamic"
            , "spark.sql.hive.convertMetastoreParquet": "false"
            , "hive.exec.dynamic.partition": "true"
            , "hive.exec.dynamic.partition.mode": "nonstrict"})

    log.warn(f"PySpark {pipeline} starting")
    print("Spark Confs: " + str(spark.sparkContext.getConf().getAll()))

    # set parameters with conf dictionary
    p = Conf(config)  # cg.set_param(config)
    print(f"JSON Config dictionary: {config}")
    print(f"Params: {str(vars(p))}")

    # Check if all parameters are set needed for load_sql
    if not p.check_params(pipeline):
        print(f"Not all required params are set for {pipeline}, abort")
        sys.exit(1)

    load(spark, p, log)
    log.warn("Finished")
    spark.stop()


# entry point for PySpark ETL application
if __name__ == "__main__":
    main("appcycle_update")

