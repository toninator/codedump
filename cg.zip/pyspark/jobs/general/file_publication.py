"""
FilePublication.py 
PROD : ./spark-submit.sh jobs/general/file_publication.py jobs/sap/account_balance/account_balance_prod.json,jobs/sap/account_balance/account_balance.sql
DEV: ./spark-submit.sh jobs/general/file_publication.py jobs/sap/account_balance/account_balance_dev.json,jobs/sap/account_balance/account_balance.sql
./spark-submit.sh /home/shbr/file_publication.py /home/shbr/account_balance_dev.json,/home/shbr/account_balance.sql
"""

import sys
import cgcommon.cgspark as cg
import cgcommon.fscmd as fc
import cgcommon.dataframe as df
from cgcommon.params import Conf
from datetime import datetime
import traceback


def extract(spark, p, log):
    """Read data from hive or parquet"""

    query_file = p.query_file
    print(query_file)
    # read extract sql query string from config
    query = cg.get_query(log, query_file)
    log.info(query)
    print(query)

    # runs query to create spark dataframe work
    work = spark.sql(query).repartition(200)
    df.insert_into(spark, work, log, "filepub", f"{p.interface_name}_stg", p.adls_extract_loc_stg)
    work_df = spark.sql(f"select * from filepub.{p.interface_name}_stg")

    count_val = work_df.count()
    print(f"Number of records in data frame: {count_val}")
    if len(work_df.head(1)) == 0:
        print("No data to publish")
        sys.exit(1)
    work_df.show()

    return work_df


def convert_to_csv(source_df, p, log):
    """Convert dataframe to CSV"""

    try:
        print(p.adls_extract_loc)
        print(p.adls_publish_loc)
        print(p.filename)

        # Commands
        tstcmd = f"-test -e {p.adls_publish_loc}"
        cpcmd = f"-cp {p.adls_extract_loc}/part* {p.adls_publish_loc}/{p.filename}"
        mkdircmd = f"-mkdir {p.adls_publish_loc}"

        # Save Data as CSV to ADLS
        print("save csv")
        source_df.coalesce(1).write.csv(p.adls_extract_loc, mode="Overwrite", sep="|", header=True, quoteAll=True, compression="gzip")

        # Copy, Rename & Move file in ADLS
        # will need to handle when folders don't exist in target_app and interface level
        result = fc.fscmd(tstcmd)
        print(f"Printing execution result : {result}")
        if result == 0:
            fc.fscmd(cpcmd)
        else:
            print("Directory missing, creating directory then copy")
            fc.fscmd(mkdircmd)
            fc.fscmd(cpcmd)
    except Exception as e:
        print(str(e))
        print(traceback.print_exc())


def main(pipeline):
    """Main for etl job"""
    if len(sys.argv) > 1:
        file_list_with_path = sys.argv[1].split(",")
        file_list = [f.split("/")[-1] for f in file_list_with_path]
    else:
        file_list = []

    # get spark session, logger, and config dict
    spark, log, config = cg.start_spark(
        app_name='FilePublication'
        , files=file_list
        , spark_conf={"spark.sql.session.timeZone": "UTC"
            , "spark.sql.sources.partitionOverwriteMode": "dynamic"
            , "spark.sql.hive.convertMetastoreParquet": "false"
            , "hive.exec.dynamic.partition": "true"
            , "hive.exec.dynamic.partition.mode": "nonstrict"
                      })

    log.warn(f"PySpark {pipeline} starting")
    print(spark.sparkContext.getConf().getAll())

    p = Conf(config)
    print(f"JSON Config dictionary: {config}")
    print(f"Params: {str(vars(p))}")
    if not p.check_params(pipeline):
        print(f"Not all required params are set for {pipeline}, abort")
        sys.exit(1)

    p.current_dt = datetime.now()
    p.folder_name = p.current_dt.strftime("%Y%m%d")
    p.file_timestamp = p.current_dt.strftime("%Y%m%d%H%M%S")

    # ADLS Path
    p.adls_extract_loc_stg = f"{p.target_loc}/{p.interface_name}/extract/{p.folder_name}_stg"
    p.adls_extract_loc = f"/tmp/pyspark/filepub/extract/{p.folder_name}"
    p.adls_publish_loc = f"{p.target_loc}/{p.interface_name}/publish"
    p.filename = f"{p.interface_name}_{p.file_timestamp}.csv.gz"

    # extract with spark.sql or dataframes api
    source_df = extract(spark, p, log)
    convert_to_csv(source_df, p, log)

    log.warn("Finished")
    spark.stop()

    return


# entry point for PySpark ETL application
if __name__ == "__main__":
    main("file_publication")
