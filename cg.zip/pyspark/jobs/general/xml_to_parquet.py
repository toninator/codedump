"""
load_sql.py
"""

import sys

import cgcommon.cgspark as cg
import cgcommon.dataframe as df
from cgcommon.params import Conf


def main(pipeline):
    """Main for etl job"""

    # delimited list argument passed
    file_list = cg.get_filenames()

    # get spark session, logger, and config dict
    spark, log, config = cg.start_spark(
        app_name=pipeline
        , jars=file_list
        , spark_conf={"spark.sql.session.timeZone": "UTC"
            , "spark.sql.sources.partitionOverwriteMode": "dynamic"
            , "spark.sql.hive.convertMetastoreParquet": "false"
            , "hive.exec.dynamic.partition": "true"
            , "hive.exec.dynamic.partition.mode": "nonstrict"
            , "spark.sql.shuffle.partitions": 64})

    log.warn(f"PySpark {pipeline} starting")

    source_df = spark.read.format('xml')\
        .options(rowTag='CA')\
        .load('adl://lasradl1oz.azuredatalakestore.net/lasr/data/landing/mft/camp/*.xml')

    source_df.write.mode("overwrite").parquet("/tmp/pyspark/camp")

    log.warn("Finished")
    spark.stop()

    return None


# entry point for PySpark ETL application
if __name__ == "__main__":
    main("xml_to_parquet")
