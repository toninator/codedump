"""
load_sql.py
"""

import sys

import cgcommon.cgspark as cg
import cgcommon.dataframe as df
from cgcommon.params import Conf


def extract(spark, p, log):
    """Read data from hive or parquet"""

    # read extract sql query string from config
    query = cg.get_query(log, p.query_file)
    log.warn(query)
    print(query)

    # runs query to create spark dataframe work
    work = spark.sql(query)
    # handle any other transformation here

    # check quality
    work = df.check_quality(work)

    # persist table to prepared zone, this could be a common method from cgcommon
    df.insert_into(spark, work, log, p.database, f"{p.table}_work", p.parent_path)
    work_df = spark.sql(f"select * from {p.database}.{p.table}_work")
    return work_df


def load(spark, source_df, p, log):
    """Loads dataframe to table"""

    # add dw columns to source dataframe
    source_dw_df = df.add_dw_columns(source_df, p)

    # using function from dataframe module, with data drive conf
    target_df = df.extract_compare_set(spark, p.database, p.table, p.part_col, p.partition_filter)

    cdc_df = df.change_data_capture(spark, source_dw_df, target_df, p, log)

    df.insert_into(spark, cdc_df, log, p.database, p.table, p.parent_path
                   , part_column=p.part_col
                   , part_reference=p.partition_reference
                   , part_number=4
                   , part_column_type=p.partition_type)

    return None


def main(pipeline):
    """Main for etl job"""

    # delimited list argument passed
    file_list = cg.get_filenames()

    # get spark session, logger, and config dict
    spark, log, config = cg.start_spark(
        app_name=pipeline
        , files=file_list
        , spark_conf={"spark.sql.session.timeZone": "UTC"
            , "spark.sql.sources.partitionOverwriteMode": "dynamic"
            , "spark.sql.hive.convertMetastoreParquet": "false"
            , "hive.exec.dynamic.partition": "true"
            , "hive.exec.dynamic.partition.mode": "nonstrict"
            , "spark.sql.shuffle.partitions": 64
            , "spark.sql.autoBroadcastJoinThreshold": 1
            , "spark.sql.crossJoin.enabled" : "true"})

    log.warn(f"PySpark {pipeline} starting")
    print("Spark Confs: " + str(spark.sparkContext.getConf().getAll()))

    # set parameters with conf dictionary
    p = Conf(config)  # cg.set_param(config)
    print(f"JSON Config dictionary: {config}")
    print(f"Params: {str(vars(p))}")

    # Check if all parameters are set needed for load_sql
    if not p.check_params(pipeline):
        print(f"Not all required params are set for {pipeline}, abort")
        sys.exit(1)

    # extract with spark.sql or dataframes api
    source_df = extract(spark, p, log)

    load(spark, source_df, p, log)

    log.warn("Finished")
    spark.stop()

    return None


# entry point for PySpark ETL application
if __name__ == "__main__":
    main("load_sql")
