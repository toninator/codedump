"""
load_sql.py
"""

import cgcommon.cgspark as cg
import cgcommon.dataframe as df
from cgcommon.params import Conf


def extract(spark, log, p):
    """Read data from hive or parquet"""

    # read extract sql query string from config
    query = cg.get_query(log, p.query_file)
    log.warn(query)
    print(query)

    # runs query to create spark dataframe work
    work = spark.sql(query)

    # handle any other transformation here

    # check quality
    work = df.check_quality(work)

    # persist table to prepared zone, this could be a common method from cgcommon
    # cg.create_external(spark, work, log, p.db, p.work_table, p.work_path)
    # work.write.insertInto("{}.{}".format(p.db, p.work_table), overwrite=True)
    # df.insert_into(work, p.db, p.work_table)

    return work


def load(spark, source_df, p, log):
    """Loads dataframe to table"""

    # add dw columns to source dataframe
    # source_dw_df = df.add_dw_columns(source_df, p)

    # check if target table exists and create
    cg.create_external(spark, source_df, log, p.db, p.target_table, p.target_path, p.part_col)

    # using function from dataframe module, with data drive conf
    # target_df = df.extract_compare_set(spark, p)

    # cdc_df = df.change_data_capture(source_dw_df, target_df, p, log)
    load_df = df.add_partition_column(source_df, p)
    df.insert_into(load_df, p.db, p.target_table)
    return None


def main():
    """Main for etl job"""
    # delimited list argument passed
    file_list = cg.get_filenames()

    # get spark session, logger, and config dict
    spark, log, config = cg.start_spark(
        app_name='load_sql'
        , files=file_list
        , spark_conf={"spark.sql.session.timeZone": "UTC"
            , "spark.sql.sources.partitionOverwriteMode": "dynamic"
            , "spark.sql.hive.convertMetastoreParquet": "false"
            , "hive.exec.dynamic.partition": "true"
            , "hive.exec.dynamic.partition.mode": "nonstrict"
            , "spark.sql.shuffle.partitions": 64})

    log.warn("PySpark load_sql starting")
    print("Spark Confs: " + str(spark.sparkContext.getConf().getAll()))

    # set parameters with conf dictionary
    p = Conf(config)  # cg.set_param(config)

    # extract with spark.sql or dataframes api
    source_df = extract(spark, log, p)

    load(spark, source_df, p, log)

    log.warn("Finished")
    spark.stop()

    return None


# entry point for PySpark ETL application
if __name__ == '__main__':
    main()

