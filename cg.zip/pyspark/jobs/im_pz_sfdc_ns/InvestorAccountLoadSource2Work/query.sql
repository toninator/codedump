SELECT
coalesce(CAST(b.DWInstitutionalOfficeID As bigint),-9999999999) As DWInstitutionalOfficeID,
coalesce(CAST(a.SFDC_INVESTOR_ACCOUNT_ID As varchar(18)),'UNKNOWN') As SfdcInvestorAccountID,
coalesce(CAST(a.SFDC_OFFICE_ID As varchar(18)),'UNKNOWN') As SfdcOfficeID,
coalesce(CAST(a.NAME As varchar(30)),'UNKNOWN') As AccountNumber,
CAST(a.DESCRIPTOR__C As varchar(30)) As DescriptorText,
CAST(a.INCEPTION_DATE__C As timestamp) As InceptionDate,
CAST(a.CONTRACTING_PARTY__C As varchar(250)) As CGContractingCompanyName,
CAST(a.TAX_STATUS__C As varchar(10)) As TaxExemptFlag,
CAST(a.TERMINATION_DATE__C As timestamp) As TerminationDate,
CAST(a.ACCT_ABBREVIATED_NAME__C As varchar(255)) As AcctAbbreviatedName,
CAST(a.INV_MANAGEMENT_CO__C As varchar(6)) As CGManagementCompany,
CAST(a.ACCOUNT_LEGAL_DOMICILE__C As varchar(120)) As FinancialAccountLegalDomicileName,
CAST(a.SRS__C As varchar(50)) As FinancialAccountSRSNumber,
CAST(a.MANDATE__R_NAME As varchar(80)) As OneProduct,
CAST(a.STATEMENT_NAME__C As varchar(255)) As StatementName,
CAST(a.TA__C As varchar(20)) As TAAccountIdentifier,
CAST(a.Source_System__c As varchar(10)) As AccountOwner,
CAST(a.CG_CONTRACTING_COMPANY__C As varchar(6)) As CGContractingCompany
from standard.sfdc_investor_account_1_v1_current a
cross join (
    select cycledate as cd
    from im_pz_sharedrefdata_ns.appcycledate
    where cyclecode like 'IM-Daily%') acd
left join im_pz_sfdc_ns.institutionaloffice b
on a.SFDC_Office_Id = b.sfdcofficeid
where acd.cd BETWEEN b.dweffectivefromdate and b.dweffectivetodate
