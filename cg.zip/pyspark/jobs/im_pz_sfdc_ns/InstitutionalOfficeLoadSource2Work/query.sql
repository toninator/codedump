SELECT
    CAST(a.Sfdc_Office_Id AS varchar(18)) AS SfdcOfficeID,
    CAST(a.Local_Name_c AS varchar(100)) AS OrganisationLocalName,
    CAST(a.Name AS varchar(120)) AS InstitutionalOfficeName,
    CAST(a.Sector_c AS varchar(50)) AS OrganisationSector
    FROM standard.sfdc_institutional_office_1_v1_current a
