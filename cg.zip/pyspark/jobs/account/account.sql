SELECT
    IIA.INVSR_ACCT_HOLDG_ID,
    FSC.FUND_SHARE_CLASS_NUM,
    IAH.PSEUD_TX_ID,
    IAH.FRST_INV_DT,
    IIA.AFIS_IND,
    IIA.RPT_SET_CD,
    IAH.SETUP_DT
FROM
    prepare_dw.invsr_acct_holding_FACT IIA
LEFT JOIN prepare_dw.invsr_acct_holding IAH
ON IIA.INVSR_ACCT_HOLDG_ID = IAH.INVSR_ACCT_HOLDG_ID and IAH.SRC_SYS_CD = 301
LEFT JOIN
    (
        SELECT 
            FUND_SHARE_CLASS_NUM, FUND_SHARE_CLASS_ID
         FROM 
            prepare_dw.FUND_SHARE_CLASS 
    ) FSC
ON
    FSC.FUND_SHARE_CLASS_ID = IIA.FUND_SHARE_CLASS_ID   
WHERE
    IIA.SRC_SYS_CD = 301 AND IIA.MO_NUM = (SELECT FROM_UNIXTIME(UNIX_TIMESTAMP(prmtr_value_date), 'YYYYMM') FROM prepare_int.etl_config WHERE prmtr_name = 'current_monthly_cycle_date')
