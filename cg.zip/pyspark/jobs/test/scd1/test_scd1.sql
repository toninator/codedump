select * from sall.cgcompany_work
