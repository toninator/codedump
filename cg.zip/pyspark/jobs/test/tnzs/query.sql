select 1 as col1, "b" as col2, current_timestamp as load_date
