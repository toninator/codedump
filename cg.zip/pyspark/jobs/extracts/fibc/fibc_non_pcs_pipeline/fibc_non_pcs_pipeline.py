"""
FIBC Non PCS Data
"""
import sys
import cgcommon.cgspark as cg
import cgcommon.fscmd as fc
from cgcommon.params import Conf
import traceback
from datetime import datetime


def main(pipeline):
    # delimited list argument passed
    if len(sys.argv) > 1:
        file_list_with_path = sys.argv[1].split(",")
        file_list = [f.split("/")[-1] for f in file_list_with_path]
    else:
        file_list = []

    # get spark session, logger, and config dict
    spark, log, config = cg.start_spark(
        app_name='FibcNonPcsPipeline'
        , files=file_list
        , spark_conf={"spark.sql.session.timeZone": "UTC"
            , "spark.sql.sources.partitionOverwriteMode": "dynamic"
            , "spark.sql.hive.convertMetastoreParquet": "false"
            , "hive.exec.dynamic.partition": "true"
            , "hive.exec.dynamic.partition.mode": "nonstrict"})

    log.warn(f"PySpark {pipeline} starting")
    print(spark.sparkContext.getConf().getAll())

    p = Conf(config)
    print(f"JSON Config dictionary: {config}")
    print(f"Params: {str(vars(p))}")
    if not p.check_params(pipeline):
        print(f"Not all required params are set for {pipeline}, abort")
        sys.exit(1)

    p.current_dt = datetime.now()
    p.folder_name = p.current_dt.strftime("%Y%m%d")
    p.file_timestamp = p.current_dt.strftime("%Y%m%d%H%M%S")

    p.adls_extract_loc_stg = f"{p.target_loc}/{p.interface_name}/extract/{p.folder_name}_stg"
    p.adls_extract_loc = f"/tmp/pyspark/filepub/extract/{p.folder_name}"
    p.adls_publish_loc = f"{p.target_loc}/{p.interface_name}/publish"
    p.filename = f"{p.interface_name}_{p.file_timestamp}.csv.gz"

    # Initiate process of Extract & Publish
    df = extract(spark, log, p)
    publish(spark, df, p, log)

    log.warn("Finished")
    spark.stop()
    return None


def extract(spark, log, p):
    """Read data from hive or parquet"""

    # Todo : Remove below date hardcoding, use it maximize result size.
    # Uncomment below code to calculate logic.
    appcycledate = '2019-01-01'
    # appcycledate = spark.sql("""
    # select cast(cycledate as string) as cd
    # from im_pz_sharedrefdata_ns.appcycledate
    # where cyclecode like 'IM-Daily%'
    # """).collect()[0]['cd'][:19]
    log.info("cycledate = " + appcycledate)

    # Query is taking 32 sec on Dev with current data
    # Prod currently has 1 Million records and takes 2 min.
    # We have to achieve similar performance numbers
    rawTradeQuery = """
	SELECT t.*
	FROM 
	(
		SELECT 
			--Trade
			T.TradeId as TradeBlockId,  TA.Version, T.TradeExecutionTimestamp, T.TraderInitials, T.VendorTraderLocationName, T.PlacementNumber,
			T.CurrentStateName, T.ExecutionTypeCode,T.VendorSecurityGroup, T.VendorSecurityTypeCode, T.TransactionType ,T.DwListingId,T.VendorCounterparty,
			T.VendorSecurityMasterIsoCurrencyCode,T.RoundRobinTradeInd,T.TradePurposeName,T.TradeType
			--Trade Allocation
			,TA.TradeAllocationId,TA.ManagerInitials,
			row_number() over (partition by TA.TradeId, TA.TradeAllocationId order by TA.Version desc) rnk
		FROM IM_pz_TRADE_S.FITrade T
		INNER JOIN IM_pz_TRADE_S.FITradeAllocation TA
		ON T.TradeID = TA.TradeId
		   and T.Version = TA.TradeVersion
		WHERE TA.InvestmentPortfolioTypeCode = 'AA' --AND T.TradeType= 'MARKET_TRADE'
		AND T.TransactionType not in ('CIN','COUT', 'COUT RETURN','CIN RETURN','CALL','MERGER') -- Not In EXCLUDES Null TransactionType
		AND T.TraderInitials not in  ('NETMAR', 'VARMAR', 'sysload', 'rm_mat')-- Not In EXCLUDES Null TraderIntial
	) as t 
		WHERE rnk = 1 and t.CurrentStateName NOT IN ('Cancelled','Invalid')
	"""
    dfRawTrade = spark.sql(rawTradeQuery)
    dfRawTrade.registerTempTable("rawTrade")

    # Query is taking 21 minute on Dev with current data.
    # Consider breaking into small chunks and figure out which table is pain area.
    assetInfoQuery = """
	SELECT
	--Instrument
	i.PrimaryInstrumentTypeCode, i.SecondaryInstrumentTypeCode, i.TertiaryInstrumentTypeCode,
	i.PrimaryInstrumentTypeName, i.SecondaryInstrumentTypeName, i.TertiaryInstrumentTypeName,
	CAST(i.CGCountryUID AS VARCHAR(50)) AS CGCountryUID, i.CGISOAlphaCountryCode, i.CGCountryName, CAST(i.InstrumentUnitParDivisorNumber AS VARCHAR(50)) AS InstrumentUnitParDivisorNumber
	, CAST(i.InstrumentFixedCouponRate AS VARCHAR(50)) AS InstrumentFixedCouponRate	, i.InstrumentLongName,	i.UnitParTradeIndicator, CAST(i.MaturityDate AS VARCHAR(50)) AS MaturityDate
	, CAST(i.OriginalDtdDate AS VARCHAR(50)) AS OriginalDtdDate, i.InstrumentCUSIPID, i.InstrumentIsinID, 
	---
	CAST(i.AgainstCurrencyUID AS VARCHAR(50)) AS AgainstCurrencyUID, CAST(i.ContractCurrencyUID AS VARCHAR(50)) AS ContractCurrencyUID, CAST(i.MaturityPrice AS VARCHAR(50)) AS MaturityPrice, i.EuroDollarIndicator, i.DebtMunicipalBondTypeCode,
	i.MunicipalBondRegionCode, i.SwapContractTypeCode, i.SwapContractTypeName, i.SwapContractClearingTypeCode,CAST(i.InstrumentUID AS VARCHAR(50)) AS InstrumentUID,
	---
	i.CouponTypeCode, i.PerpetualIndicator, i.CoupontypeName, i.ShortTermIndicator, i.SinkingfundIndicator, i.CollateralShortDescription, i.DebtLoanTypeCode, i.DebtLoanTypeName, 
	--i.MortgageToBeActualizedIndicator, *** REINSTATE. This column is necessary and should be available in Prod
	i.TaxExemptIndicator, CAST(i.FuturesContractSizeNumber AS VARCHAR(50)) AS FuturesContractSizeNumber,i.MortgageToBeAllocatedIndicator,
	--
	CAST(l.ListingFinancialMarketUID AS VARCHAR(50)) AS ListingFinancialMarketUID,FM.FinancialMarketName,
	--Listing
	CAST(l.ListingCurrencyUID AS VARCHAR(50)) AS ListingCurrencyUID, l.ListingLongName, l.AssetCategoryName, CAST(l.ListingUid AS VARCHAR(50)) AS ListingUid,CAST(l.DwListingId AS VARCHAR(50)) AS DwListingId,
	--Issuer
	CAST(iss.IssuerCGCountryUID AS VARCHAR(50)) AS IssuerCGCountryUID, iss.IssuerCGCountryCode, iss.IssuerCGCountryName, CAST(iss.IssuerCountryOfHeadquartersUID AS VARCHAR(50)) AS IssuerCountryOfHeadquartersUID, iss.IssuerCountryOfHeadquartersCode, iss.IssuerCountryOfHeadquartersName, 
	CAST(iss.IssuerCountryOfIncorporationUID AS VARCHAR(50)) AS IssuerCountryOfIncorporationUID, iss.IssuerCountryOfIncorporationCode, iss.IssuerCountryOfIncorporationName, CAST(iss.IssuerCountryOfUltimateRiskUID AS VARCHAR(50)) AS IssuerCountryOfUltimateRiskUID
	, iss.IssuerCountryOfUltimateRiskCode, iss.IssuerCountryOfUltimateRiskName, 	iss.IssuerLongName,iss.IssuerFTSECountryName,iss.IssuerMSCICountryCountryName,iss.IssuerTaxCountryName,CAST(iss.IssuerUid AS VARCHAR(50)) AS IssuerUid,
	--GICS Industry
	gic.SectorName as GICSSectorName, gic.IndustryGroupName as GICSIndustryGroupName, gic.IndustryName as GICSIndustryName, gic.SubIndustryName as GICSSubIndustryName,
	--ICB Industry
	icb.IndustryName as ICBIndustryName, icb.SuperSectorName as ICBSuperSectorName, icb.SectorName as ICBSectorName, icb.SubSectorName as ICBSubSectorName,
	--Barclays Industry
	bic.BarclaysClass1, bic.BarclaysClass2, bic.BarclaysClass3, bic.BarclaysClass4, 
	--CGP Industry
	cgp.SectorName as CGPSectorName, cgp.IndustryGroupName as CGPIndustryGroupName, cgp.IndustryName as CGPIndustryName, cgp.SubIndustryName as CGPSubindustryName	


	FROM IM_pz_SHAREDREFDATA_NS.Listing l
	INNER JOIN IM_pz_SHAREDREFDATA_NS.Instrument I  ON l.DWInstrumentId = I.DWInstrumentID
	INNER JOIN IM_pz_SHAREDREFDATA_NS.Issuer iss  ON l.DWIssuerID = iss.DWIssuerID
	LEFT  JOIN IM_pz_SHAREDREFDATA_NS.BarclaysIndustryClassification bic   ON l.DWBarclaysIndustryClassificationID = bic.DWBarclaysIndustryClassificationID
	LEFT  JOIN IM_pz_SHAREDREFDATA_NS.CGPIndustryClassification cgp ON I.DWCGPIndustryClassificationID=cgp.DWCGPIndustryClassificationID
	LEFT  JOIN IM_pz_SHAREDREFDATA_NS.ICBIndustryClassification icb ON I.DWICBIndustryClassificationID=icb.DWICBIndustryClassificationID
	LEFT  JOIN IM_pz_SHAREDREFDATA_NS.GICSIndustryClassification gic   ON I.DWGICSIndustryClassificationID = gic.DWGICSIndustryClassificationID
	LEFT  JOIN IM_pz_SHAREDREFDATA_NS.FinancialMarket FM On FM.DWFinancialMarketID=l.DWListingFinancialMarketID
	WHERE 
			-- Filter Swap & FWD legs
			 (I.SecondaryInstrumentTypeCode NOT IN ('FWD','SWA')
			OR (I.SecondaryInstrumentTypeCode = 'FWD' AND l.RelatedLegUID IS NOT NULL )-- As CSTAR table IM_pz_ACCTPOSTRANS_S.AccountFinancialTransaction don't have contract leg*/)
			OR (I.SecondaryInstrumentTypeCode = 'SWA' AND swaplegtypecode IS NULL)
			OR I.SecondaryInstrumentTypeCode IS NULL -- In case assets present with null SecondaryInstrumentTypeCode should not filter.
			)

	"""
    dfAssetInfo = spark.sql(assetInfoQuery)
    dfAssetInfo.registerTempTable("CGAssetInfo")

    finalResultQuery = """
	SELECT 
	--Identification Field
	--~~~~~~~~~~~~~~~~~
	'NonPCS' RecordType
	--Trade/Transaction
	--~~~~~~~~~~~~~~~~~
	
	,CAST(ft.TradeIdentifier AS VARCHAR(50)) AS TradeIdentifier
	,CAST(ft.InvestmentAccountUID AS VARCHAR(50)) AS InvestmentAccountUID
	,CAST(ft.BrokerUID AS VARCHAR(50)) AS BrokerUID
	,CAST(ft.ActivityDate AS VARCHAR(50)) AS TradeDate
	,CAST(ft.TradePrice AS VARCHAR(50)) AS TradePrice
	,CAST(rt.TradeBlockId AS VARCHAR(50)) AS TradeBlockId
	,rt.TraderInitials
	,rt.VendorTraderLocationName AS  TradingLocation
	,CAST(rt.PlacementNumber AS VARCHAR(50)) AS PlacementNumber
	,rt.ExecutionTypeCode
	,rt.VendorSecurityGroup
	,rt.VendorSecurityTypeCode
	,rt.TransactionType
	,rt.ManagerInitials
	,rt.VendorCounterparty
	,rt.VendorSecurityMasterIsoCurrencyCode VendorSecurityMasterCurrencyCode
	,rt.RoundRobinTradeInd
	,rt.TradePurposeName

	
	,CAST(ft.TransactionShareParQuantity AS VARCHAR(50)) AS TransactionShareParQuantity
	,CAST(ft.FinancialMarketUID  AS VARCHAR(50)) AS FinancialMarketUID
	,CAST(ft.FinancialTransactionCreatedTimestamp   AS VARCHAR(50)) AS FinancialTransactionCreatedTimestamp
	,CAST(ft.TransactionEventDate  AS VARCHAR(50)) AS TransactionEventDate
	,ft.TransactionTypeCode 
	,ft.TransactionDetailTypeCode 
	,CAST(ft.LocalGrossAmount  AS VARCHAR(50)) AS  LocalGrossAmount

	--Listing,Instrument,Issuer,Industry
	--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	,ast.*
	
	--Indicator Flags
	--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	,Li.IsCDXInd,Li.IsCDXEMInd,Li.IsCDXHYInd,Li.IsCDXIGInd,Li.IsGOVInd,Li.IsCorporateInd,Li.IsEmergingMarketInd,Li.IsHighYieldInd,Li.IsInvestmentGradeInd,Li.IsFutureInd,Li.IsIRSInd

	--Rating
	--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	,Fir.BarclayRatingLevel2 BarclayRating,Fir.MoodyRating MdyRatingValueCode,CAST(Fir.MoodyRankingValueNumber AS VARCHAR(50)) AS  MdyRatingRankingValueNumber,Fir.FitchRating FitchRatingValueCode
	,CAST(Fir.FitchRankingValueNumber AS VARCHAR(50)) AS  FitchRatingRankingValueNumber,Fir.SPRating SPRatingValueCode,CAST(Fir.SPRankingValueNumber AS VARCHAR(50)) AS  SPRatingRankingValueNumber
	,Fir.CGRating CgRatingValueCode,CAST(Fir.CGRankingValueNumber AS VARCHAR(50)) AS  CgRRatingRankingValueNumber
	
	--Breakdown Data
	--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	,FiBrRat.BreakdownLevel1,FiBrCon.BreakdownLevel1 as BreakdownCGMSCILevel1,FiBrCon.BreakdownLevel2 as BreakdownCGMSCILevel2,FiBrCon.BreakdownLevel3 as BreakdownCGMSCILevel3

	--ExchangeRate
	--~~~~~~~~~~~~
	,erBuy.FromCurrencyCode as LocalCurrencyCode
	, CAST((CASE WHEN erBuy.MultiplyDivideCode='M' THEN 1/erBuy.Rate ELSE erBuy.Rate END) AS VARCHAR(50)) AS LocalToUSDExchangeRate
	--,erSell.FromCurrencyCode as LocalSellCurrencyCode, erSell.Rate as SellLocalToUSDExchangeRate

	--New Field Addition to the file end
	--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	,rt.TradeType
		
	FROM IM_pz_ACCTPOSTRANS_S.AccountFinancialTransaction ft 
	INNER JOIN CGAssetInfo ast ON ft.DWListingId=ast.DWListingId
	LEFT JOIN IM_pz_PRICING_S.ExchangeRate erBuy  
	ON ft.LocalCurrencyUID = erBuy.FromCurrencyUID 
		AND ft.ActivityDate = erBuy.RateDate
		AND erBuy.ToCurrencyCode = 'USD' 
		AND erBuy.RateTableCode = 'CG' 
		AND erBuy.PriceTypeCode = 'MID'
		AND erBuy.DaysForwardCount = 0

	LEFT JOIN RawTrade rt
		  ON ft.TradeIdentifier = rt.TradeAllocationId
	LEFT  JOIN IM_pz_SHAREDREFDATA_NS.ListingFIIndicator Li on Li.DwListingId = ast.DwListingId 
	LEFT  JOIN IM_pz_SHAREDREFDATA_NS.ListingFIRating Fir On Fir.DwListingId=ast.DwListingId
	LEFT  JOIN IM_pz_FIREPORTING_NS.ListingFIBreakdown FiBrk On FiBrk.ListingUID=ast.ListingUID 
	LEFT  JOIN IM_pz_FIREPORTING_NS.FIBreakdownCGMSCICountry FiBrCon ON FiBrk.DWFIBreakdownCGMSCICountryID=FiBrCon.DWFIBreakdownCGMSCICountryID
	LEFT  JOIN IM_pz_FIREPORTING_NS.FIBreakdownCGBarclaysRating FiBrRat ON FiBrRat.DWFIBreakdownCGBarclaysRatingID=FiBrk.DWFIBreakdownCGBarclaysRatingID
	WHERE ft.RecordType = 'INITIAL_TRANSACTION'
	AND NOT EXISTS ( SELECT 1 FROM IM_pz_ACCTPOSTRANS_S.AccountFinancialTransaction 
					WHERE ft.FinancialTransactionDetailID = AccountFinancialTransaction.FinancialTransactionDetailID
					AND ft.InvestmentAccountUID = AccountFinancialTransaction.InvestmentAccountUID and ft.ListingUID = AccountFinancialTransaction.ListingUID 
					AND RecordType = 'CANCEL')
	AND activitydate >= '{0}'
	and ft.ActivityDate  between Li.DwEffectiveFromDate AND Li.DwEffectiveToDate 
	AND ft.ActivityDate between Fir.DwEffectiveFromDate AND Fir.DwEffectiveToDate 
	AND ft.ActivityDate between FiBrk.DwEffectiveFromDate AND FiBrk.DwEffectiveToDate
	AND ft.TransactionTypeCode NOT IN ('FWDMAT') -- Not In clause Excludes NULL TransactionTypeCode
	AND (ast.PrimaryInstrumentTypeCode <> 'E' OR PrimaryInstrumentTypeCode IS NULL)
	AND ft.TradeIdentifier NOT IN ('0', '9999999','-9999999999')
	AND (
			-- This is to filter one leg of Forward which has is the delivery amount of contract to be treated as notional 
			ast.SecondaryInstrumentTypeCode  NOT IN ('FWD')
			OR 
			( ast.SecondaryInstrumentTypeCode = 'FWD'  AND ast.ContractCurrencyUID=ft.LocalCurrencyUID)	
			OR ast.SecondaryInstrumentTypeCode IS NULL
		)
	"""
    dfFinalResult = spark.sql(finalResultQuery.format(appcycledate))
    return dfFinalResult


def publish(spark, source_df, p, log):
    """Loads dataframe to table"""

    print("Publishing Data")

    try:
        print(p.adls_extract_loc)
        print(p.adls_publish_loc)
        print(p.filename)

        # Commands
        tstcmd = f"-test -e {p.adls_publish_loc}"
        cpcmd = f"-cp {p.adls_extract_loc}/part* {p.adls_publish_loc}/{p.filename}"
        mkdircmd = f"-mkdir {p.adls_publish_loc}"

        # Save Data as CSV to ADLS
        print("save csv")
        source_df.coalesce(1).write.csv(p.adls_extract_loc, mode="overwrite", sep="|", header=True, quoteAll=True, compression="gzip")
        print("csv saved")
        # Copy, Rename & Move file in ADLS
        # will need to handle when folders don't exist in target_app and interface level
        result = fc.fscmd(tstcmd)
        print(f"Printing execution result : {result}")
        if result == 0:
            fc.fscmd(cpcmd)
        else:
            print("Directory missing, creating directory then copy")
            fc.fscmd(mkdircmd)
            fc.fscmd(cpcmd)
    except Exception as e:
        print(str(e))
        print(traceback.print_exc())

    return None


# entry point for PySpark ETL application
if __name__ == '__main__':
    main("file_publication")
