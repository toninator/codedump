#!/bin/bash
cd "$(dirname "$0")"
echo $#
if [ $# -eq 0 ]
  then
    echo "No arguments supplied"
    exit 1

fi

pyjob=$1
jobconf=$2

if [ $# -eq 1 ]
  then
    echo "No conf supplied"
    jobconf=$1
fi


export PY3VENVZIP=venv/py36.zip
echo $PY3VENVZIP
echo $pyjob
echo $jobconf

PYSPARK_PYTHON=./py36/py36/bin/python3 spark2-submit \
--master yarn \
--deploy-mode cluster  \
--conf spark.yarn.appMasterEnv.PYSPARK_PYTHON=./py36/py36/bin/python \
--conf spark.driver.maxResultSize=2g \
--driver-memory 8g \
--py-files cgcommon.zip \
--archives $PY3VENVZIP#py36 \
--files $jobconf \
$pyjob $jobconf

