
from pathlib import Path
import os
from subprocess import run

# for mac: sudo vim /etc/hosts, add entry: 127.0.0.1 <macbook_asset_id>.capgroup.com if you want it to work outside of vpn. it needs loopback

def check_cg_java(version="1.8"):
    """ Check for CG Installation of Java and set JAVA_HOME """
    try:
        java_home = os.environ["JAVA_HOME"]
        v = run([os.path.join(java_home, "bin", "java"), "--version"], capture_output=True)
        raise ValueError #TODO
        print("Found Java in JAVA_HOME")
    except KeyError as e:
        print(f"JAVA_HOME not set in environment variables.")
    except Exception:
        print("Could not use JAVA_HOME in environment variable...")

    try:
        path = run(["/usr/libexec/java_home", "-v", "1.8"], capture_output=True) # TODO: extract this stuff into its own loader module
        print("Found JAVA_HOME through libexec")
        return {"JAVA_HOME": path.stdout.decode().strip('\n') }      
    except KeyError as e:
        print("No JAVA_HOME set, trying to find it...")
    
    raise NotImplementedError("Please Install JDK 1.8 from CGAppStore")


def runner():
    env = check_cg_java()
    return env


def loader():
    envs = runner()
    for key, value in envs.items():
        os.environ[key] = value