from .setup_windows import loader as win_load
from .setup_nix import loader as nix_load
from pathlib import Path, WindowsPath, PosixPath
import os


def load():
    p = Path(".")
    if isinstance(p, PosixPath):
        print("*Nix Device Detected")
        nix_load()
    elif isinstance(p, WindowsPath):
        print("Windows Device Detected")
        win_load()


