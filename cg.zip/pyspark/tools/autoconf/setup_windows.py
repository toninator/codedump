# because windows is terrible

from pathlib import Path
import os
import wget
import tarfile
from subprocess import run
import shutil

def check_cg_java(version="1.8"):
    """ Check for CG Installation of Java and set JAVA_HOME """
    try:
        java_home = os.environ["JAVA_HOME"]
        #output = run([str(Path(Path(java_home) / "bin" / "java")), "--version"]) #TODO
        if version in java_home:
            return { "JAVA_HOME": java_home}
        print(f"JAVA_HOME set, but not {version}. Trying to find it...")
    except KeyError as e:
        print("No JAVA_HOME set, trying to find it...")
    
    java_install_path = Path(r"C:\Java\JDK\JDK1~1.8UP") # use 8.3_filename: https://en.wikipedia.org/wiki/8.3_filename
    java_install_path_2 = Path(r"C:\PROGRA~1\Java\jdk1.8.0_241")
    if java_install_path.exists():
        env = {
            "JAVA_HOME": os.path.join(str(java_install_path), "64Bit~1") #set JAVA_HOME=C:\Java\JDK\JDK1~1.8UP\64Bit~1
        }
        return env
    raise NotImplementedError("Please Install JDK 1.8 from CGAppStore")


def install_hadoop_winutils(version="2.6.0", download=True):
    """
    WinUtils is required for sql context to communicate with the Windows FS
    """   
    hadoop_winutils_folder = Path(os.path.join("libs", f"hadoop-winutils-{version}"))
    if not hadoop_winutils_folder.exists() and download is True: # install it
        print("Installing Hadoop WinUitls.exe")
        url = f"https://cgrepo.capgroup.com/repository/cgfiles/hadoop/winutils/{version}/winutils.exe" # original url: https://github.com/steveloughran/winutils/raw/master/hadoop-{version}/bin/winutils.exe
        bin = Path(hadoop_winutils_folder / "bin")
        bin.mkdir(parents=True, exist_ok=True)
        fname = wget.download(url, out=str(bin))
    
    # scratch folder is created for hive at: /tmp/hive
    env = {
        "HADOOP_HOME": str(hadoop_winutils_folder.absolute()), # set HADOOP_HOME=C:\Users\KNXA2a\code\pyspark\hadoop-2.7.1,
    }
    return env
     
def install_hadoop(version="2.7.1", download=True):
    """ 
    https://sigdelta.com/blog/how-to-install-pyspark-locally/ for now.. no time to recompile my own binary
    Use redistributed binary already built for windowsx64
    Set HADOOP_HOME
    Fix File Permission for default storage location {tmp_storage}
    TODO: Clean this up and make it properly
    """
    hadoop_installation_folder = Path(os.path.join("libs", f"hadoop-{version}"))

    if not hadoop_installation_folder.exists() and download is True: # install it
        print("Installing Hadoop Binaries")

        url = f"https://github.com/karthikj1/Hadoop-{version}-Windows-64-binaries/releases/download/v{version}/hadoop-{version}.tar.gz"
        fname = wget.download(url)
        tar = tarfile.open(fname, "r:gz")
        tar.extractall()
        tar.close()
    hive_scratch = Path(r"C:\tmp\hive") # hive scratch
    hive_scratch.mkdir(parents=True, exist_ok=True) # make the tmp folder
    run([ os.path.join(os.getcwd(), hadoop_installation_folder, "bin", "winutils.exe"), "chmod", "777", str(hive_scratch) ]) #.\hadoop-2.7.1\bin\winutils.exe chmod 777 {tmp_storage}
    
    env = {
        "HADOOP_HOME": str(hadoop_installation_folder.absolute()), # set HADOOP_HOME=C:\Users\KNXA2a\code\pyspark\hadoop-2.7.1,
        "PATH": f'{os.environ["PATH"]};{os.path.join(os.environ["HADOOP_HOME"], "bin")}', #set PATH=%PATH%;C:\Users\KNXA2a\code\pyspark\hadoop-2.7.1\bin
    }
    return env


def runner():
    env = check_cg_java()
    hadoop_env = install_hadoop_winutils()
    env.update(hadoop_env)
    return env


def loader():
    envs = runner()
    for key, value in envs.items():
        os.environ[key] = value


if __name__ == "__main__":
    loader()
    