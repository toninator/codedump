#!/bin/bash

cd "$(dirname "$0")"

zip -r cgcommon.zip cgcommon

