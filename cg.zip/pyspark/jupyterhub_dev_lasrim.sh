


## Setup the Notebook

dzdo su jd0lcmsr

### install the jupyterhub in a virtual environment

JUPYTERHUB_HOME=/users/apps/jupyterhub
mkdir -p $JUPYTERHUB_HOME
cd $JUPYTERHUB_HOME
/users/python/python36/bin/python -m venv jupyterhub

echo "[global]
index = https://cgrepo.capgroup.com/repository/cgpypi/pypi/
index-url = https://cgrepo.capgroup.com/repository/cgpypi/simple/
trusted-host = cgrepo.capgroup.com" > $JUPYTERHUB_HOME/jupyterhub/pip.conf

$JUPYTERHUB_HOME/jupyterhub/bin/pip install jupyterhub notebook py4j jupyterlab


## install the http proxy server - jupyterhub requires this

NODEJS_HOME=$JUPYTERHUB_HOME/nodejs
mkdir -p $NODEJS_HOME
cd $NODEJS_HOME
wget https://cgrepo.capgroup.com/repository/cgfiles/nodejs/10.13.0/node-v10.13.0-linux-x64.tar.xz
tar xvf node-v10.13.0-linux-x64.tar.xz -C $NODEJS_HOME
rm -rf node-v10.13.0-linux-x64.tar.xz
ln -s $NODEJS_HOME/node-v10.13.0-linux-x64 $NODEJS_HOME/node
export PATH=$NODEJS_HOME/node/bin:$PATH

#echo 'export PATH=$NODEJS_HOME/node/bin:$PATH' >> /etc/bashrc
#source ~/.bashrc

npm install -g configurable-http-proxy

## Configure Jupyterhub and the kernels

cd $JUPYTERHUB_HOME
jupyterhub --generate-config
sed -i "s~#c.Authenticator.admin_users = .*~c.Authenticator.admin_users = {'knxa', 'jpbg', 'tnzs'}~g" $JUPYTERHUB_HOME/jupyterhub_config.py
sed -i "s~#c.JupyterHub.bind_url = .*~c.JupyterHub.bind_url = 'http://0.0.0.0:8080'~g" $JUPYTERHUB_HOME/jupyterhub_config.py
sed -i "s~#c.JupyterHub.authenticator_class = .*~c.JupyterHub.authenticator_class = 'jupyterhub.auth.PAMAuthenticator'~g" $JUPYTERHUB_HOME/jupyterhub_config.py
sed -i "s~#c.Spawner.default_url = .*~c.Spawner.default_url = '/lab'~g" $JUPYTERHUB_HOME/jupyterhub_config.py # because jupyterlab is prettier
sed -i "s~#c.JupyterHub.extra_log_file = .*~c.JupyterHub.extra_log_file = '/var/log/jupyterhub.log'~g" $JUPYTERHUB_HOME/jupyterhub_config.py  # you'll probs need to log rotate this or something

# You should get ssl if you are gonna host this to make sure the traffic in flight is encrypted. Once you make a cert request, you can move the private and public key to the server and use the below to point the ssl certs.
#sed -i "s~#c.JupyterHub.ssl_cert = .*~c.JupyterHub.ssl_cert = '/etc/ssl/certs/capgroup.com.ssl/cert.cer.txt'~g" $JUPYTERHUB_HOME/jupyterhub_config.py
#sed -i "s~#c.JupyterHub.ssl_key = .*~c.JupyterHub.ssl_key = '/etc/ssl/certs/capgroup.com.ssl/key.pem'~g" $JUPYTERHUB_HOME/jupyterhub_config.py

## use the below if you see env variables getting dropped off that you're expecting to have. all the dependencies should be in the kernel for now so it shouldnt matter.
#sed -i "s~#c.Spawner.env_keep = .*~c.Spawner.env_keep = ['PATH', 'PYTHONPATH', 'CONDA_ROOT', 'CONDA_DEFAULT_ENV', 'VIRTUAL_ENV', 'LANG', 'LC_ALL', 'SPARK_HOME', 'JAVA_HOME', 'HADOOP_HOME', 'HADOOP_CLASSPATH', 'SPARK_DIST_CLASSPATH', 'HADOOP_CREDSTORE_PASSWORD', 'SPARK_AUTHENTICATE_SECRET']~g" $JUPYTERHUB_HOME/jupyterhub_config.py

## Make the pyspark kernel

mkdir - p $JUPYTERHUB_HOME/jupyterhub/share/jupyter/kernels/pyspark2

### Usually it should include py4j, but it doesnt seem to be the right version so i just installed it through pip.... should probably revisit this to see if any underlying issue.
# "PYTHONPATH": "/opt/cloudera/parcels/SPARK2/lib/spark2/python/lib/py4j*.zip:/opt/cloudera/parcels/SPARK2/lib/spark2/python/",
# "PYTHONPATH": "/opt/cloudera/parcels/SPARK2/lib/spark2/python/",
###

echo '{
    "argv": [
        "/users/apps/jupyterhub/jupyterhub/bin/python",
        "-m",
        "ipykernel_launcher",
        "-f",
        "{connection_file}"
    ],
    "display_name": "PySpark2Python3",
    "language": "python",
    "env": {
        "SPARK_HOME": "/opt/cloudera/parcels/SPARK2/lib/spark2/",
        "PYSPARK_PYTHON": "/users/python/python36/bin/python",
        "PYTHONSTARTUP": "/opt/cloudera/parcels/SPARK2/lib/spark2/python/pyspark/shell.py",
        "HADOOP_CONF_DIR": "/etc/hadoop/conf:/etc/hive/conf",
        "PYTHONPATH": "/opt/cloudera/parcels/SPARK2/lib/spark2/python/",
        "JAVA_HOME": "/usr/java/default"
    }
}' > $JUPYTERHUB_HOME/jupyterhub/share/jupyter/kernels/pyspark2/kernel.json


#### RUN THE NOTEBOOK as root once...

dzdo su # root #PAM Authenticator needs root.... so service is starting in root

JUPYTERHUB_HOME=/users/apps/jupyterhub
NODEJS_HOME=$JUPYTERHUB_HOME/nodejs

export PATH=$JUPYTERHUB_HOME/jupyterhub/bin:$PATH
export PATH=$NODEJS_HOME/node/bin:$PATH

jupyterhub -f jupyterhub_config.py


### RUN THE NOTEBOOK as a service...
dzdo su  # root #PAM Authenticator needs root.... so service is starting in root

JUPYTERHUB_HOME=/users/apps/jupyterhub
NODEJS_HOME=$JUPYTERHUB_HOME/nodejs

export PATH=$JUPYTERHUB_HOME/jupyterhub/bin:$PATH
export PATH=$NODEJS_HOME/node/bin:$PATH

echo "[Unit]
Description=Jupyterhub

[Service]
Type=simple
User=root
LimitNOFILE=65536
Environment='JUPYTERHUB_HOME=/users/apps/jupyterhub'
Environment='NODEJS_HOME=$JUPYTERHUB_HOME/nodejs'
Environment='PATH=$NODEJS_HOME/node/bin:$JUPYTERHUB_HOME/jupyterhub/bin:$PATH'
ExecStart=/users/apps/jupyterhub/jupyterhub/bin/jupyterhub -f jupyterhub_config.py
WorkingDirectory=/users/apps/jupyterhub

[Install]
WantedBy=multi-user.target" > /etc/systemd/system/jupyterhub.service

systemctl daemon-reload
systemctl enable jupyterhub
systemctl restart jupyterhub
systemctl status jupyterhub

################# Adding / Registering Users
# must have access to the server. it is using PAM authentication. then we can just create the home dir if they have never logged in yet.
#Run this to make their home folder (if they havent already made one by logging into the server) mkhomedir_helper <initials>
