#!/usr/bin/env bash

# ------------------------------------------------------------------------
# Build automation environment configuration
# ------------------------------------------------------------------------

# ------------------------------------------------------------------------
#  Insert environment configuration code below
# ------------------------------------------------------------------------

SCRIPT=$(readlink -f "$0")
# Absolute path this script is in
BUILD_PATH=$(dirname "$SCRIPT")
export BUILD_PATH

PYTHON=/users/python/python36/bin/python
export PYTHON

BUILD_UTIL=${CG_TOOLS_HOME}/c/interface_scripts/buildutil/python
export BUILD_UTIL

JUNIT_RESULTS_PATH=./cgbuild/dist/reports/JUnit
export JUNIT_RESULTS_PATH

FULL_VERSION=${CG_APP_VERSION}.${CG_BUILD_NUMBER}
export FULL_VERSION

BASEDIR=${BUILD_PATH}/../../../
export BASEDIR