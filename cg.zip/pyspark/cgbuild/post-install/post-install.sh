BUILD_RC=0

echo "executing installer..."
echo "working dir2: ${CGPKG_WORKING_DIR}"
echo "target dir2:  ${CGPKG_TARGET_DIR}"

${CGPKG_TARGET_DIR}/zip_cgcommon.sh

BUILD_RC=$?

if [ ${BUILD_RC} -ne 0 ]
then
  echo Build step failed with code ${BUILD_RC}
  exit 1
fi

echo Completed installer successfully
exit $?
